﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reportes.Genericas
{
    public static class Extensions
    {
        public static string MyToString(this DateTime? dt)
        {
            return dt?.ToString("d") ?? string.Empty;
        }
    }
}
