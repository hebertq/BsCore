﻿using Modelo.Interfaces;
using System;
using System.Xml.Serialization;

namespace Modelo.ClasesGenericas
{
    /// <summary>
    /// Información de la transacción actual de un usuario
    /// </summary>  
    [Serializable()]  //indica explicitamente que esta clase es serializable
    public class UserInfo : IUserInfo
    {
        /// <summary>
        /// Nombre del usuario
        /// </summary>]
        [XmlIgnore()]
        public string UserName { set; get; }
        /// <summary>
        /// Contraseña del Cliente
        /// </summary>
        [XmlIgnore()]
        public string PassName { set; get; }
        /// <summary>
        /// Identificador del cliente
        /// </summary>
        [XmlIgnore()]
        public decimal NoCliente { set; get; }
        /// <summary>
        /// Nombre de la base de datos
        /// </summary>
        [XmlIgnore()]
        public string EmisorDB { set; get; }
        /// <summary>
        /// Nombre del contexto
        /// </summary>
        [XmlIgnore()]
        public InfoTipoContext ContextoDB { set; get; }
        /// <summary>
        /// Usuario para generar Token
        /// </summary>]
        [XmlIgnore()]
        public string UserToken { set; get; }
        /// <summary>
        /// Inicializacion de variables
        /// </summary>
        public void SetUserInfo(UserInfo info)
        {
            this.UserName = info.UserName;
            this.NoCliente = info.NoCliente;
            this.EmisorDB = info.EmisorDB;
            this.ContextoDB = info.ContextoDB;
            this.PassName = info.PassName;
            this.UserToken = info.UserToken;
        }
    }
}