﻿using Modelo.Entradas.BLNI;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

namespace Modelo.ClasesGenericas
{
    public class LogCalificacionACN
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        [XmlAttribute(AttributeName = "Puntaje")]
        public int Puntaje { set; get; } = 0;        
        public LogCalificacionActividadEconomica Actividad_Economica { set; get; } = new LogCalificacionActividadEconomica();
        public LogCalificacionPais Riesgo_geografico { set; get; } = new LogCalificacionPais();
        public LogCalificacionProducto Poducto { set; get; } = new LogCalificacionProducto();
        public LogCalificacionCredito Creditos { set; get; } = new LogCalificacionCredito();
        public LogCalificacionPep Pep { set; get; } = new LogCalificacionPep();
    }

    public class LogCalificacionDifNat
    {
        public string NoCaso { set; get; } = string.Empty;
        public string NoCliente { set; get; } = string.Empty;

        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        public LogCalificacionACN CalificacionLA { set; get; } = new LogCalificacionACN();
        public LogCalificacionACN CalificacionAutomatica { set; get; } = new LogCalificacionACN();
        public LogCalificacionACN CalificacionFT { set; get; } = new LogCalificacionACN();
        public LogCalificacionACN CalificacionFP { set; get; } = new LogCalificacionACN();
    }

    public class LogCalificacionDifNatResponse
    {
        public string NoCaso { set; get; } = string.Empty;
        public string NoCliente { set; get; } = string.Empty;

        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        public LogCalificacionACN CalificacionLA { set; get; } = new LogCalificacionACN();
        public LogCalificacionACN CalificacionFT { set; get; } = new LogCalificacionACN();
        public LogCalificacionACN CalificacionFP { set; get; } = new LogCalificacionACN();
    }

    public class LogCalificacionDifNatResponseJsa
    {
        public string NoCaso { set; get; } = string.Empty;
        public string NoCliente { set; get; } = string.Empty;

        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        public LogCalificacionACJ CalificacionLA { set; get; } = new LogCalificacionACJ();
        public LogCalificacionACJ CalificacionFT { set; get; } = new LogCalificacionACJ();
        public LogCalificacionACJ CalificacionFP { set; get; } = new LogCalificacionACJ();
    }

    public class LogCalificacionPep
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion { set; get; } = 0;
        public int Pnp { set; get; } = 0;
        public int ClientePep { set; get; } = 0;
        public int RelacionPnp { set; get; } = 0;
        public int ClientePeriodoPep { set; get; } = 0;
        public int PepFirmantes { set; get; } = 0;
        public int RelacionadosPep { set; get; } = 0;
    }

    public class LogCalificacionCredito
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion { set; get; } = 0;
        public int cantCreditos { set; get; } = 0;
        public int sumCreditos { set; get; } = 0;
    }
    public class LogCalificacionProducto
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion { set; get; } = 0;
        public int Cuentas { set; get; } = 0;
        public int BackToBack { set; get; } = 0;
        public int CertificadosDTO { set; get; } = 0;
        public int Tc_Prepagos { set; get; } = 0;
        [XmlElement(ElementName = "TarjetasCredito")]
        public int TcDebito { set; get; } = 0;
        public LogCalificacionPrestamos Prestamos { set; get; } = new LogCalificacionPrestamos();
    }

    public class LogCalificacionPrestamos
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion
        {
            get
            {
                calPrestamo = Asociados.Count > 0 ? Asociados.OrderBy(a => a.Calificacion).First().Calificacion : 0;
                return calPrestamo > 0 ? 1 : 0;
            }
            set
            {
                calPrestamo = value;
            }
        }
        [XmlElement(ElementName = "PrestamosAsociados")]
        public List<PrestamosAsociados> Asociados { set; get; } = new List<PrestamosAsociados>();

        [XmlIgnore]
        private decimal calPrestamo;

    }
    public class PrestamosAsociados
    {
        public string NoGL { set; get; } = string.Empty;
        public string Descripcion { set; get; } = string.Empty;
        public int Calificacion { set; get; } = 0;
    }


    public class LogCalificacionActividadEconomica
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion { set; get; } = 0;
        public int ActEcoSinRiesgo { set; get; } = 0;
        public int ActEconomica { set; get; } = 0;
    }

    public class LogCalificacionPais
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int Calificacion { set; get; } = 0;
        public int Pais { set; get; } = 0;
        public int Departamento { set; get; } = 0;
    }
}
