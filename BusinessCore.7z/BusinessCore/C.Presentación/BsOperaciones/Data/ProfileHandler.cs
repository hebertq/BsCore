﻿using Blazored.LocalStorage;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks; 
namespace BsOperaciones.Data
{
    public class ProfileHandler : AuthorizationHandler<ProfileOwnerRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ProfileOwnerRequirement requirement)
        {
            if (context.User.Identity.IsAuthenticated)
            {                
                var resource = context.Resource?.ToString();
                var hasParsed = int.TryParse(resource, out int profileID);
                if (hasParsed)
                {
                    if (IsOwner(context.User, profileID))
                    {
                        context.Succeed(requirement);
                    }
                }
            }

            return Task.CompletedTask;
        }
        private bool IsOwner(ClaimsPrincipal user, int profileID)
        {
            // compare the requested memberId to the user's actual claim of 
            // memberId
            //  var isAuthorized = context.User.GetMemberIdClaim();
            // now we know if the user is authorized or not, and can act 
            // accordingly

            var _profileID = user.Claims.Where(x => x.Type == "UserMenu").FirstOrDefault().Value;
            //return _profileID == profileID;
            return !string.IsNullOrEmpty(_profileID);
        }
    }
}
