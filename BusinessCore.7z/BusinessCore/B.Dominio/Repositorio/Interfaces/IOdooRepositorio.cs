﻿using Modelo.Interfaces;
using Modelo.Salida;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IOdooRepositorio
    {
        Task<IListResponse<ComboDatos>> GetAllEmpleados();
    }
}
