﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entradas.BLHNI
{
    public abstract class BaseRiesgoCliente
    {
        public decimal NoCliente { set; get; } = 0;
        public string  TipoCliente { set; get; } = "";
        public string  Riesgo { set; get; } = "";
        public string  ActividadEconomica { set; get; } = "";
        public decimal SumCreditoEsperado { set; get; } = 0;
        public decimal CantCreditoEsperado { set; get; } = 0;
    }
}
