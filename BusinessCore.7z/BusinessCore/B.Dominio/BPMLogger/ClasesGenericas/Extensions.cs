﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Net.Mail;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace BPMLogger.ClasesGenericas
{
    public static class Extensions
    {
        /// <summary>
        /// Serializador JSON
        /// </summary>
        /// <typeparam name="T">Tipo Referencia a Serealizar</typeparam>
        /// <param name="t">Entidad a serealizar</param>
        /// <returns>Objeto string serealizado</returns>
        public static string JsonSerializer<T>(T t)
        {
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
            MemoryStream ms = new MemoryStream();
            ser.WriteObject(ms, t);
            string jsonString = Encoding.UTF8.GetString(ms.ToArray());
            ms.Close();
            return jsonString;
        }
        /// <summary>
        /// Desealizador JSON
        /// </summary>
        /// <typeparam name="T">Tipo de referenia deserealizado</typeparam>
        /// <param name="jsonString">Objeto string a deseralizar</param>
        /// <returns>Objeto Deseralizado</returns>
        public static T JsonDeserialize<T>(string jsonString)
        {
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
            MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(jsonString));
            T obj = (T)ser.ReadObject(ms);
            return obj;
        }

        /// <summary>
        /// Convierte un arreglo de Byte en formato UTF8 a Cadena
        /// </summary>
        /// <param name="pbytes">arreglo byte con formato UTF8</param>
        /// <returns></returns>
        public static String UTF8ByteArrayToString(Byte[] pbytes)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = encoding.GetString(pbytes);
            return (constructedString);
        }

        /// <summary>
        /// Coniverte un xml string a arreglo de byte
        /// </summary>
        /// <param name="pXmlString">xml</param>
        /// <returns>Arreglo de byte</returns>
        public static Byte[] StringToUTF8ByteArray(String pXmlString)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            Byte[] byteArray = encoding.GetBytes(pXmlString);
            return byteArray;
        }

        /// <summary>
        /// Deserealiza un xml a una estructura de datos
        /// </summary>
        /// <typeparam name="T">Clase a deserealizar</typeparam>
        /// <param name="pXmlizedString">Datos de tipo xml</param>
        /// <returns>Objeto deserealizado a entidad</returns>
        public static T DeserializeObject<T>(String pXmlizedString)
        {
            XmlSerializer xs = new XmlSerializer(typeof(T));
            MemoryStream memoryStream = new MemoryStream(StringToUTF8ByteArray(pXmlizedString));
            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
            return (T)xs.Deserialize(memoryStream);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Clase"></param>
        /// <returns></returns>
        public static string SerializeXml<T>(object Clase, string NombreRoot = "")
        {
            string xml = null;
            try
            {
                XmlDocument xdoc = new XmlDocument();
                StringWriter sww = new StringWriter();
                XmlWriterSettings setting = new XmlWriterSettings { OmitXmlDeclaration = true };

                XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
                namespaces.Add(string.Empty, string.Empty);

                XmlWriter writer = XmlWriter.Create(sww, setting);
                XmlSerializer xsSubmit = null;

                xsSubmit = string.IsNullOrEmpty(NombreRoot) ? new XmlSerializer(((T)Clase).GetType()) : new XmlSerializer(((T)Clase).GetType(), new XmlRootAttribute(NombreRoot));

                xsSubmit.Serialize(writer, (T)Clase, namespaces);
                xml = sww.ToString();

            }
            catch (Exception ex)
            {
                xml = ex.Message;
            }
            return xml;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ruta"></param>
        /// <returns></returns>
        public static T DesSerializeXml<T>(string ruta) where T : class
        {
            XmlReader reader = XmlReader.Create(ruta);
            return new XmlSerializer(typeof(T)).Deserialize(reader) as T;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static byte[] StreamToByteArray(this Stream stream)
        {
            stream.Position = 0;
            byte[] buffer = new byte[stream.Length];
            for (int totalBytesCopied = 0; totalBytesCopied < stream.Length;)
                totalBytesCopied += stream.Read(buffer, totalBytesCopied, Convert.ToInt32(stream.Length) - totalBytesCopied);
            return buffer;
        }

        /// <summary>
        /// Envia correo de nitificacion sobre un evento
        /// </summary>
        /// <param name="subject">Asunto</param>
        /// <param name="from">De</param>
        /// <param name="to">Para</param>
        /// <param name="cc">Copia</param>
        /// <param name="bcc">Copia Oculta</param>
        /// <param name="body">Cuerto</param>
        public static void SendEmail(string subject, string from, string to, string cc, string bcc, string body)
        {
            try
            {
                MailMessage mail = new MailMessage(from.Replace(";", ","), to.Equals(string.Empty) ? ConfigurationManager.AppSettings["EMAIL_ADMIN"].Replace(";", ",") : to.Replace(";", ","));
                //MailMessage mail = new MailMessage("rob.munguia@gmail.com", "rmunguia@lafise.com", "", "");
                SmtpClient client = new SmtpClient();

                client.Host = ConfigurationManager.AppSettings["EMAIL_SERVER"];
                subject = (ConfigurationManager.AppSettings["MODO_PRUEBA"].ToUpper() == "SI" ? "Prueba: " : "Producción: ") + subject;

                mail.IsBodyHtml = true;
                mail.Subject = subject;
                mail.Body = body;
                mail.Priority = MailPriority.High;

                if (bcc.Length > 0)
                    mail.Bcc.Add(bcc);

                client.Send(mail);
                mail = null;
                client = null;
            }
            catch (Exception ex)
            {
                throw ex;
                //clsLog.Log("BizAgiCreditoWS.txt", ex.Message);
            }
        }

        /// <summary>
        /// //Derterminar si un directorio existe
        /// </summary>
        /// <param name="Directorio">Ruta del directorio</param>
        /// <returns>Bandera de resultado</returns>
        public static Boolean existeDIRECTORIO(string Directorio)
        {
            // Comprobar si existe un directorio:
            if (Directory.Exists(Directorio))
                return true;
            else
                return false;
        }

        /// <summary>
        /// MOSTRAR FICHERO DE UN DIRECTORIO
        /// </summary>
        /// <param name="DirecctorioX">Un directorio</param>
        /// <param name="filtro">*.txt</param>
        /// <param name="Ficheros">Listado de archivos en el directorio</param>
        /// <returns>Listado de archivos en el directorio</returns>
        public static string MostrarFicheros(string DirecctorioX, string filtro, ref ArrayList Ficheros)
        {
            StringBuilder RESULTADO = new StringBuilder("");
            if (DirecctorioX.Trim().Length == 0 || filtro.Trim().Length == 0 || Ficheros == null)
                return RESULTADO.Insert(0, "Alguno de los parámetros no han sido inicializados").ToString();

            try
            {
                if (existeDIRECTORIO(DirecctorioX))
                {
                    RESULTADO.Append("--->Los ficheros " + filtro + " del directorio: " + DirecctorioX + " son: ");

                    System.IO.DirectoryInfo root = new DirectoryInfo(DirecctorioX);
                    System.IO.FileInfo[] files = root.GetFiles(filtro);

                    foreach (var Fichero in files)
                    {
                        RESULTADO.Append(" Fichero: " + Fichero);
                        Ficheros.Add(Fichero.Name);
                    }
                }
                else
                    RESULTADO.Append("El directorio " + DirecctorioX + "no existe");
            }
            catch (Exception EX)
            {
                RESULTADO.Insert(0, EX.Message.ToString());
            }
            return RESULTADO.ToString().Trim();
        }

        /// <summary>
        /// Crear cuerpo del sms.
        /// </summary>
        /// <param name="usuario">Usuario al cual esta dirigido el smsm</param>
        /// <param name="Asunto">Asunto del sms</param>
        /// <param name="titulo1">Titulo del sms</param>
        /// <param name="nombreEmpresa">Entides relacionada</param>
        /// <param name="CuerpoDelMensaje">Cuerpo o contenido del sms</param>
        /// <param name="NombreDestinatario">Destinatario del sms.</param>
        /// <returns></returns>
        public static StringBuilder CuerpoDelEmail(string usuario, string Asunto, string titulo1, string nombreEmpresa, string CuerpoDelMensaje, string NombreDestinatario)
        {
            String hora = DateTime.Now.ToString("hh:mm tt");
            String Fecha = DateTime.Now.Date.ToString("dd/MM/yyyy");
            StringBuilder str = new StringBuilder();

            str.AppendLine("<html>");
            str.AppendLine("<head>");
            str.AppendLine("<title>" + Asunto + "</title>");
            str.AppendLine("<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>");
            str.AppendLine("<style type='text/css'>");
            str.AppendLine("<!--");
            str.AppendLine(".Estilo1 {font-family: Arial, Helvetica, sans-serif}");
            str.AppendLine(".Estilo2 {");
            str.AppendLine("color: #990000;");
            str.AppendLine("font-weight: bold;");
            str.AppendLine("}");
            str.AppendLine(".Estilo3 {");
            str.AppendLine("font-size: 14px;");
            str.AppendLine("color: #000000;");
            str.AppendLine("}");
            str.AppendLine(".Estilo7 {color: #0000FF; font-weight: bold; }");
            str.AppendLine(".Estilo8 {color: #0000FF}");
            str.AppendLine("-->");
            str.AppendLine("</style>");
            str.AppendLine("</head>");

            str.AppendLine("<body>");
            str.AppendLine("<p></p>");
            str.AppendLine("<table width='815'>");
            str.AppendLine("<tr>");
            str.AppendLine("<td colspan='8'><div align='center'><strong>" + Asunto + "</strong></div></td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td colspan='8'><div align='center'>");
            str.AppendLine("<h1 class='Estilo1'>" + titulo1 + "</h1>");
            str.AppendLine("</div></td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td colspan='8'><div align='center'><strong>" + nombreEmpresa + "</strong></div></td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td colspan='8'><div align='center'>");
            str.AppendLine("<h4 class='Estilo2 Estilo3'> " + CuerpoDelMensaje + " </h4>");
            str.AppendLine("</div></td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td><span class='Estilo2'>USUARIO:</span></td>");
            str.AppendLine("<td width='76'><span class='Estilo2'>" + usuario + "</span></td>");
            str.AppendLine("<td width='243'>&nbsp;</td>");
            str.AppendLine("<td width='184'>&nbsp;</td>");
            str.AppendLine("<td width='14'>&nbsp;</td>");
            str.AppendLine("<td>&nbsp;</td>");
            str.AppendLine("<td>&nbsp;</td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td width='116'></td>");
            str.AppendLine("<td width='76'></td>");
            str.AppendLine("<td></td>");
            str.AppendLine("<td></td>");
            str.AppendLine("<td></td>");
            str.AppendLine("</tr>");
            str.AppendLine("<tr>");
            str.AppendLine("<td colspan='8'><div align='center'></div></td>");

            str.AppendLine("</tr>");
            str.AppendLine("<tr bgcolor='#CCFFCC'>");
            str.AppendLine("<td colspan='8'><strong>Detalles : </strong></td>");
            str.AppendLine("</tr>");

            str.AppendLine("<tr>");
            str.AppendLine("<td>FECHA: </td>");
            str.AppendLine("<td>" + Fecha + " </td>");
            str.AppendLine("<td>&nbsp;</td>");
            str.AppendLine("<td colspan='4'>&nbsp;</td>");
            str.AppendLine("<td width='1'></td>");
            str.AppendLine("</tr>");

            str.AppendLine("<tr>");
            str.AppendLine("<td>MENSAJE ENVIADO A: </td>");
            str.AppendLine("<td> " + NombreDestinatario + " </td>");
            str.AppendLine("<td>&nbsp;</td>");
            str.AppendLine("<td colspan='4'>&nbsp;</td>");
            str.AppendLine("<td></td>");
            str.AppendLine("</tr>");

            str.AppendLine("<tr>");
            str.AppendLine("<td>Hora: </td>");
            str.AppendLine("<td>" + hora + "</td>");
            str.AppendLine("<td>&nbsp;</td>");
            str.AppendLine("<td colspan='4'>&nbsp;</td>");
            str.AppendLine("<td></td>");
            str.AppendLine("</tr>");

            str.AppendLine("</table>");
            str.AppendLine("<br>");
            str.AppendLine("</body>");
            str.AppendLine("</html>");

            return str;
        }

        ////Diferencia de tiempo entre dos fechas
        //public static long DateDiff(String UnidadDeMedida, String fechaInicial, String fechaFinal)
        //{
        //    long result = VB.DateAndTime.DateDiff(UnidadDeMedida, fechaInicial, fechaFinal);
        //    return result;
        //}

        /// <summary>
        /// Metodo para convertir List<T> a DataTable
        /// </summary>
        /// <typeparam name="T">Nombre del ObjetResult a convertir</typeparam>
        /// <param name="data">Data a convertir a DataTable</param>
        /// <returns>DataTable</returns>
        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();

            foreach (PropertyDescriptor prop in properties)
            {
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }

            return table;
        }


        /// <summary>
        /// Metodo para serializar un datatable a json
        /// </summary>
        /// <returns></returns>
        public static string JsonSerializerDataTable(DataTable dt)
        {
            var jsondatatable = JsonConvert.SerializeObject(dt);
            return jsondatatable ?? string.Empty;
        }

        /// <summary>
        /// Convierte un objeto a string xml
        /// </summary>
        /// <typeparam name="T">tipo de objeto origen</typeparam>
        /// <param name="tipo">objeto tipo</param>
        /// <returns>string xml</returns>
        public static string ToXml<T>(this T tipo)
        {
            string xmlTmp = string.Empty;
            StringWriter writer = new StringWriter();
            XmlSerializer ser = new XmlSerializer(tipo.GetType());

            ser.Serialize(writer, tipo);
            xmlTmp = writer.ToString();
            writer.Close();

            return xmlTmp;
        }


        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethod()
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);

            return sf.GetMethod().Name;
        }

        /// <summary>
        /// Quitar arreglo de bytes
        /// </summary>
        /// <param name="pObjecto">Objeto a quitar limpiar los datos Byte</param>
        /// <param name="pTieneTiposByte">Enviar false para indicar que no tiene y no evaluar el objeto</param>
        public static void QuitarDatoByte(object pObjeto, bool pTieneTiposByte = true)
        {
            // Si el invocador sabe que no tiene datos byte, entonces debe enviar un false
            if (!pTieneTiposByte) return;
            var pObjectoType = pObjeto.GetType();
            var pObjectoTypeAsamblieName = pObjectoType.Assembly.FullName;
            foreach (PropertyInfo prop in pObjectoType.GetProperties())
            {
                string name = prop.Name;
                object value = prop.GetValue(pObjeto, null);

                TypeCode codigoTipo = Type.GetTypeCode(prop.PropertyType);
                var esByte = prop.PropertyType.ToString().ToLower().Contains("system.byte");
                if (codigoTipo == TypeCode.Byte || esByte)
                {
                    value = Parse(prop.GetType(), null);
                    prop.SetValue(pObjeto, value);
                }
                else
                    if (prop.PropertyType.IsClass && prop.PropertyType.Assembly.FullName == pObjectoTypeAsamblieName)
                    QuitarDatoByte(value);
                //if ( codeTipo == TypeCode.Object )
                //QuitarFileByte(prop);
            }
        }
        /// <summary>
        /// Parsea objeto y devuelve null si no se soporta evitando excepcion
        /// </summary>
        /// <param name="type"></param>
        /// <param name="str"></param>
        /// <returns></returns>
        public static object Parse(Type type, string str)
        {
            try
            {
                var parse = type.GetMethod("Parse", new[] { typeof(string) });
                if (parse == null) throw new NotSupportedException();
                return parse.Invoke(null, new object[] { str });
            }
            //or don't catch
            catch (Exception)
            {
                return null;
            }
        }


        /// <summary>
        /// Hace una copia un objeto y datos permitiendo ignorar datos bytes arrays
        /// </summary>
        /// <param name="objSource">Objeto origen</param>
        /// <param name="ignoreArrays">Booleano para ignorar datos tipo byte[]</param>
        /// <returns></returns>
        public static object AutoCloneObject(this object objSource, bool ignoreArrays = false)
        {
            // Hacemos get del tipo de objeto origen y creamos una instancia de ese mismo tipo
            Type typeSource = objSource.GetType();
            object objTarget = Activator.CreateInstance(typeSource);

            // Obtenemos todas las propiedades del objeto origen de lectura y escritura 
            PropertyInfo[] propertyInfo = typeSource.GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.IgnoreCase);


            // *** Iteramos sobre todas las propiedad para asignarles su respectivo valor ***
            foreach (PropertyInfo property in propertyInfo)
            {
                if (property.CanWrite)
                {

                    //revisamos la propiedad es un value type, enum or string type
                    if (property.PropertyType.IsValueType || property.PropertyType.IsEnum || property.PropertyType.Equals(typeof(System.String)) || property.PropertyType.IsArray)
                    {
                        var propName = property.PropertyType.Name;
                        object propValue = null;
                        // Ignorar (dejando nulo) los arreglos de byte ya que no se desean clonar (cuando ignoreArrays llega true) 
                        if (!(propName == "Byte[]" && ignoreArrays))
                            propValue = property.GetValue(objSource, null);
                        property.SetValue(objTarget, propValue, null);
                    }
                    // De lo contrario la propiedad es un  object/complex,por lo tanto hacer llamados recursivos hasta lograr clonar todos los objectos
                    else
                    {
                        try
                        {
                            object objPropertyValue = property.GetValue(objSource, null);
                            property.SetValue(objTarget, objPropertyValue, null);
                        }
                        catch (Exception)
                        {
                        }
                    }
                }
            }

            // *** Iteramos sobre campos que no son atributos  ***
            var fieldInfoCollection = typeSource.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (var field in fieldInfoCollection)
            {
                // lo backinfield automaticos de propiedades no los alteramos
                if (field.Name.Contains("k__BackingField"))
                    continue;
                //var targetField = type.GetField(sourceField.Name);                
                var fieldValue = field.GetValue(objSource);
                field.SetValue(objTarget, fieldValue);
            }

            return objTarget;
        }

        public static string ObtenerValorConfig(Config option, string key)
        {
            try
            {
                switch (option)
                {
                    case Config.Key: return ConfigurationManager.AppSettings.Get(key);
                    case Config.ConnectionString: return ConfigurationManager.ConnectionStrings[key].ConnectionString;
                    default: return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
        }

        public static bool ExisteConfigKey(Config option, string key)
        {
            //if ConfigurationManager.ConnectionStrings[strConexion] == null

            if (option == Config.Key)
            {
                if (ConfigurationManager.AppSettings[key] == null)
                    return false;
            }
            else
            {
                if (ConfigurationManager.ConnectionStrings[key] == null)
                    return false;
            }
            return true;
        }

        public enum Config
        {
            Key,
            ConnectionString
        }

        public static void SetDefaultValue(object clase)
        {
            foreach (PropertyInfo propertyInfo in clase.GetType().GetProperties())
            {
                if (propertyInfo.PropertyType == typeof(string))
                {
                    if (propertyInfo.GetValue(clase, null) == null || propertyInfo.GetValue(clase, null).ToString() == string.Empty)
                        propertyInfo.SetValue(clase, "N/A");
                }
            }
        }

        public static DataTable ConvertToDataTable<T>(this List<T> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }
        public static List<T> DatatbleToList<T>(this DataTable dt, T tipo)
        {
            List<T> myInstances = new List<T>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Type MyType = tipo.GetType();
                var myInstance = Activator.CreateInstance(MyType);

                foreach (PropertyInfo pInfo in MyType.GetProperties())
                {

                    if (dt.Columns.Contains(pInfo.Name))
                    {
                        try
                        {
                            Type nameOfType = pInfo.PropertyType.GetType();
                            if (pInfo.PropertyType.FullName.Contains("System.Nullable"))
                            {
                                Object val = dt.Rows[i].Field<object>(pInfo.Name);
                                if (val != null)
                                {
                                    if (pInfo.PropertyType.FullName.Contains("DateTime"))
                                        MyType.GetProperty(pInfo.Name)
                                            .SetValue(myInstance, Convert.ToDateTime(dt.Rows[i][pInfo.Name]));

                                    if (pInfo.PropertyType.FullName.Contains("Decimal"))
                                        MyType.GetProperty(pInfo.Name)
                                            .SetValue(myInstance, Convert.ToDecimal(dt.Rows[i][pInfo.Name]));

                                    if (pInfo.PropertyType.FullName.Contains("Int"))
                                        MyType.GetProperty(pInfo.Name)
                                            .SetValue(myInstance, Convert.ToInt32(dt.Rows[i][pInfo.Name]));
                                }

                                else
                                {
                                    if (pInfo.PropertyType.FullName.Contains("Bool"))
                                        MyType.GetProperty(pInfo.Name)
                                            .SetValue(myInstance, false);
                                }

                            }
                            else
                            {
                                MyType.GetProperty(pInfo.Name).SetValue(myInstance, Convert.ChangeType(dt.Rows[i][pInfo.Name], pInfo.PropertyType));
                            }

                        }
                        catch (Exception ex)
                        {

                            throw ex;
                        }

                    }
                }
                myInstances.Add((T)myInstance);
            }

            return myInstances;
        }
        public static string ConcatenarStr(this List<string> data)
        {
            var str = string.Empty;
            foreach (var item in data)
            {
                str += item + ",";
            }
            str = str.Remove(str.Length - 1, 1);
            return str;
        }

        /// <summary>
        /// Escribir un archivo en disco hacia c:\TestReports
        /// </summary>
        /// <param name="datos">objetos de datos a exportar</param>
        /// <param name="nombreArchivo">nombre deseado del arhcivo sin extensión</param>
        /// <param name="tipo">enviar xml/txt</param>
        public static void ResultToDisk(object datos, string nombreArchivo = "test", string tipo = "xml")
        {
            var fn = nombreArchivo + "_" + DateTime.Now.ToString("yyyyMMdd") + DateTime.Now.ToString("HH:mm:ss tt zz").Replace(":", "") + ".txt";
            fn = fn.Replace(" ", "");
            System.IO.File.WriteAllText(@"C:\TestReports\" + fn, tipo == "xml" ? datos.ToXml() : datos.ToString());
        }

        public static void Map(this object parameters, object Out)
        {
            if (parameters != null)
            {
                //Get all the properties of source object type                
                PropertyInfo[] propertyInfoList = parameters.GetType().GetProperties(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.IgnoreCase);

                //foreach (PropertyInfo propertyInfo in parameters.GetType().GetProperties())
                foreach (PropertyInfo propertyInfo in propertyInfoList)
                {
                    string nameIn = propertyInfo.Name;
                    object valueIn = propertyInfo.GetValue(parameters, null);
                    foreach (PropertyInfo propertyInfoO in Out.GetType().GetProperties())
                    {
                        string nameInO = propertyInfoO.Name;
                        object valueInO = propertyInfoO.GetValue(parameters, null);
                        if (nameIn == nameInO)
                            propertyInfoO.SetValue(Out, valueInO, null);
                    }
                }
            }
        }
    }
}


