﻿using MediatR;
using Modelo.Admin;
using Modelo.Interfaces;


namespace ApplicationWeb.Features.ADMIN.Queries
{
    public record GetUserByAccessTokenQuery(RefreshRequest model) : IRequest<ISingleResponse<User>>;
}
