﻿using Modelo.Report;
using Reportes.Genericas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reportes.Clases
{
    public class RepositoriesOdoo:Repository
    {
        public string ReporteCiudad()
        {
            return CrearReporte(CreateViewModel(), "Model.docx", "Model.cs.docx");
        }

        private  MyViewModel CreateViewModel()
        {
            //var countries = new List<Country>();
            //var countries = new List<Country> { new Country { Name = "Porosika" } };
            var countries = CountryRepository.GetCountries();

            return new MyViewModel
            {
                Title = "Model Sample",
                Date = DateTime.Now.ToShortDateString(),
                Countries = countries,
                AveragePopulation = countries.Count > 0
                    ? (int)countries.Average(c => c.Population)
                    : (int?)null,
                AverageDateProclaimed = GetAverageDateProclaimed(countries)
            };
        }

        private  DateTime? GetAverageDateProclaimed(List<Country> countries)
        {
            var dates = countries
                .Where(c => c.DateProclaimed.HasValue)
                .Select(c => c.DateProclaimed.Value)
                .ToList();

            if (dates.Count == 0)
            {
                return null;
            }

            return new DateTime((long)dates
                .Aggregate<DateTime, double>(0, (current, date) => current + date.Ticks / dates.Count));
        }
    }

    public class CountryRepository
    {
        public static List<Country> GetCountries()
        {
            return new List<Country>
            {
                new Country
                {
                    Name = "Egypt",
                    Population = 96084500,
                    DateProclaimed = new DateTime(1953, 6, 18)
                },
                new Country
                {
                    Name = "Germany",
                    Population = 82349400,
                    DateProclaimed = new DateTime(1990, 10, 3)
                },
                new Country
                {
                    Name = "Ireland",
                    Population = 6378000,
                    DateProclaimed = new DateTime(1916, 4, 24)
                },
                new Country
                {
                    Name = "Israel",
                    Population = 8782260,
                    DateProclaimed = new DateTime(1948, 5, 14)
                },
                new Country
                {
                    Name = "Poland",
                    Population = 38634007,
                    DateProclaimed = new DateTime(1989, 9, 13)
                },
                new Country
                {
                    Name = "The Netherlands",
                    Population = 17170000,
                    DateProclaimed = new DateTime(1581, 7, 26)
                },
                new Country
                {
                    Name = "United States",
                    Population = 325365189,
                    DateProclaimed = new DateTime(1776, 7, 4)
                },
            };
        }
    }
}
