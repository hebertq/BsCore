﻿using System;
using System.Collections.Generic;

namespace Modelo.Admin
{
    public  class User
    {
        public int User_Id { get; set; }
        public string Email_Address { get; set; }
        public string Password { get; set; }
        public string Source { get; set; }
        public string First_Name { get; set; }
        public string Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Nav_Menu { get; set; } = "Prueba";
        public short Role_Id { get; set; }
        public int Pub_Id { get; set; }
        public DateTime? Hire_Date { get; set; }
    }

    public class UserLogin
    {
        public string Email_Address { get; set; }
        public string Password { get; set; }
    }
}
