﻿namespace BsOperaciones.Component.TypeBrowsers
{
    internal class MethodView
    {
        public string Name { get; set; }
    }
}
