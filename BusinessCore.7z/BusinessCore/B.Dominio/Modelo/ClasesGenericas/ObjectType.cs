﻿using System;

namespace Modelo.ClasesGenericas
{
    public class ObjectType
    {
        public Type type { set; get; } 
        public string name { set; get; }
        public string fullname { set; get; }
    }
}
