﻿using Blazored.LocalStorage;
using HostService.ClasesGenericas;
using HostService.Interfaces;
using Modelo.Admin;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Seguridad.ClasesGenericas;
using System;
using System.Reflection;
using System.Threading.Tasks;
using Utilidades.Interfaces;

namespace HostService.Clases
{
    public class UserService: ServiceHost, IUserService
    {
        public UserService(IUtilidades _Util, ILocalStorageService ls) : base(_Util,ls) { }
        public async Task<ISingleResponse<UserWithToken>> LoginAsync(UserLogin model)
        {
            ISingleResponse<UserWithToken> response = new SingleResponse<UserWithToken>();
            model.Password = _Util.Encrypt(model.Password);
            try
            {                
                var requestUrl = CreateRequestUri("Auth/Login");
                var registro = await PostAsync<ResponseData, UserLogin>(requestUrl, model);
                if (registro.IsSuccess)
                {
                    var reg = registro.Data;
                    if (reg.suces)
                        response.Model =  _Util.ObtenerRegistro<UserWithToken>(reg.detail.ToString());
                    else
                        response.Respuesta.SetError(reg.errors.ToString(),ErrorType.Servicio,"");

                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<ISingleResponse<User>> GetUserByAccessToken(RefreshRequest model)
        {
            ISingleResponse<User> response = new SingleResponse<User>();
            try
            {
                var requestUrl = CreateRequestUri("Auth/GetUserByAccessToken");
                var registro = await PostAsync<ResponseData, RefreshRequest>(requestUrl, model);
                if (registro.IsSuccess)
                {
                    var reg = registro.Data;
                    if (reg.suces)
                        response.Model = _Util.ObtenerRegistro<User>(reg.detail.ToString());
                    else
                        response.Respuesta.SetError(reg.errors.ToString(), ErrorType.Servicio, "");

                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }       
    }
}
