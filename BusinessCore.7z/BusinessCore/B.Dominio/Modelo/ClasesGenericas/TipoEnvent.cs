﻿using System;


namespace Modelo.ClasesGenericas
{
    public class TipoEnvent
    {
        public Type @event { set; get;}
    }
}
