﻿using Core.Interfaces;
using Utilidades.Interfaces;

namespace Repositorio.ClasesGenericas
{
    public abstract class RepositorioBase
    {
        protected IUtilidades _Util;
        protected IDapper    _dapper;
        public RepositorioBase(IDapper dapper, IUtilidades util)
        {
            _dapper = dapper;
            _Util   = util;
        }
    }
}
