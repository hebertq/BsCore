﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entidades
{
    public class ExampleModel
    {
        public string PlainText { get; set; }
        public string HtmlContent { get; set; }
    }
}
