﻿using Modelo.Interfaces;
using System.Threading.Tasks;
using Modelo.Entradas;
using Modelo.Entidades;

namespace Repositorio.Interfaces
{
    public interface IJobsRepository
    {
        Task<IResponse> AddEventsJob(BaseEvents request);
        Task<IListResponse<JobsEventsSched>> GetEventsJobSched(string Sched);
        Task<IResponse> SetProcessingJobId(int request);
    }
}
