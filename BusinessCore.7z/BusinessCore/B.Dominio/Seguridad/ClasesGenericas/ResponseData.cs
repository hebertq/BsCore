﻿using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using System;

namespace Seguridad.ClasesGenericas
{
    public class ResponseData
    {
        public ResponseData() { }
        public ResponseData(EResponse code, object data, object dataresp,string tit)
        {
            status = code;
            title  = tit;
            id     = Guid.NewGuid();
            var response = data as IResponse;           

            if (response != null)
            {
                response.SetObjet();
                errors = response.Respuesta.MensajeError;
                suces  = !response.Respuesta.ExisteError;
                title  = suces ? title : "Excepción de error de la aplicación"; 

                if (response.Respuesta.Status == ErrorType.Validación)
                    status = EResponse.ValidationError;
                if (response.Respuesta.Status == ErrorType.Servicio)
                    status = EResponse.UnSuccess;
                if (response.Respuesta.Status == ErrorType.Datos)
                    status = EResponse.UnexpectedError;
                else if (response.ObjModel != null)
                {
                    detail = response.ObjModel;
                }               
            }
            else
            {
                
                if (dataresp != null)
                {
                    detail  = dataresp;
                    errors  = "Solicitud/Transacción procesada exitosamente";
                    suces   = true;
                }                   
                else
                {
                    errors = data;
                    suces  = false;
                    title  = "Excepción de error de la aplicación";
                }                                 
            }
        }
        public Guid id { set; get; }
        public string title { set; get; } = "";
        public EResponse status { set; get; } = EResponse.OK;
        public bool suces { set; get; } = true;
        public object errors { set; get; }
        public object detail { set; get; } = null;
        //public string type { set; get; } = "";
    }
}
