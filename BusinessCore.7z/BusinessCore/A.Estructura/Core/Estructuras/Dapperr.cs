﻿using Core.ClasesGenericas;
using Core.Interfaces;
using Dapper;
using Modelo.ClasesGenericas;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Validation;
using System.Linq;
using System.Threading.Tasks;


namespace Core.Estructuras
{
    public class Dapperr : IDapper
    {
        private readonly SqlContext _SqlContext;
        private readonly NpgContext _NpgContex;

        private IDbConnection  db;
        private DatabaseProvider _context;
        private IDbTransaction dbTra;
        private bool _IsTransaction = false;
        private bool _disposed = false;
        private string errorMessage = string.Empty;
        private InformacionTransaccion _InfoTra;
        private DynamicParameters dbparams = new DynamicParameters();
        public ResultadoGenerico _InfoRespuesta { set; get; } = new ResultadoGenerico();
        public Dapperr(SqlContext sqlcontext, NpgContext npgcontext)
        {
            _SqlContext = sqlcontext;
            _NpgContex  = npgcontext;
        }

        public TipoDB _dbTipo { set; get; } = TipoDB.NPGDB;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public virtual void Dispose(bool disposing)
        {
            if (!_disposed)
                if (disposing)
                {
                    if (_SqlContext != null)
                        _SqlContext.Dispose();
                    if (_NpgContex != null)
                        _NpgContex.Dispose();
                }                  

            _disposed = true;
            _IsTransaction = false;
        }

        public IDbConnection ConnecDb
        {
            get { return db; }
        }

        public void CreateConnection()
        {
            if(_dbTipo == TipoDB.SQLDB)
            {
                _context = _SqlContext;
            }               
            else if (_dbTipo == TipoDB.NPGDB)
            {
                _context = _NpgContex;
            }
                
            _disposed = false;
        }

        public void Transaction()
        {
             CreateConnection();
            _IsTransaction = true;
            dbTra = db.BeginTransaction();
        }
        public void CommitTran()
        {
            dbTra.Commit();
        }
        public void RollbackTran()
        {
            dbTra.Rollback();
        }

        public InfoContextSQL dbcontex { set; get; }

        public async Task Execute(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            try
            {
                dbparams = new DynamicParameters();
                dbparams.PrepareParameter(parms);

                CreateConnection();
                using (var connection = await _context.GetOpenConnection(dbcontex))
                {                   
                    await connection.ExecuteAsync(sp, dbparams, commandType: commandType).ConfigureAwait(false);
                }
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                _InfoTra.SetErrordb(errorMessage);
                _InfoRespuesta.SetErrorValidation(_InfoTra, sp);
            }
            catch (Exception ex)
            {
                _InfoRespuesta.SetErrorExep(ErrorType.Datos, ex, sp);
            }          
            finally
            {
                Dispose();
            }
        }
        public async Task<T> GetAsync<T>(string sp, object parms, CommandType commandType = CommandType.Text) where T : class, new()
        {
            try
            {
                dbparams = new DynamicParameters();
                dbparams.PrepareParameter(parms);
                CreateConnection();
                using (var connection = await _context.GetOpenConnection(dbcontex))
                {
                    return await connection.QuerySingleOrDefaultAsync<T>(sp, dbparams, commandType: commandType).ConfigureAwait(false);
                }
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                _InfoTra.SetErrordb(errorMessage);
                _InfoRespuesta.SetErrorValidation(_InfoTra, sp);
                return new T();
            }
            catch (Exception ex)
            {
                _InfoRespuesta.SetErrorExep(ErrorType.Datos, ex, sp);
                return new T();
            }
            finally
            {
                Dispose();
            }
        }    
        public async Task<List<T>> GetAllAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new()
        {
            try
            {
                dbparams = new DynamicParameters();
                dbparams.PrepareParameter(parms);
                CreateConnection();
                using (var connection = await _context.GetOpenConnection(dbcontex))
                {
                    var result = await connection.QueryAsync<T>(sp, dbparams, commandType: commandType).ConfigureAwait(false);
                    return result.ToList();
                }
                
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                _InfoTra.SetErrordb(errorMessage);
                _InfoRespuesta.SetErrorValidation(_InfoTra, sp);
                return new List<T>();
            }
            catch (Exception ex)
            {
                _InfoRespuesta.SetErrorExep(ErrorType.Datos, ex, sp);
                return new List<T>();
            }
           
        }

        public async Task<DataSet> QueryMultiple(string sp, object parms, CommandType commandType = CommandType.StoredProcedure)
        {
            try
            {
                dbparams = new DynamicParameters();
                dbparams.PrepareParameter(parms);

                CreateConnection();
                using (var connection = await _context.GetOpenConnection(dbcontex))
                {
                    var result = await connection.ExecuteReaderAsync(sp, dbparams, commandType: commandType).ConfigureAwait(false);
                    return ConvertDataReaderToDataSet(result);
                }                
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                _InfoTra.SetErrordb(errorMessage);
                _InfoRespuesta.SetErrorValidation(_InfoTra, sp);
                return null;
            }
            catch (Exception ex)
            {
                _InfoRespuesta.SetErrorExep(ErrorType.Datos, ex, sp);
                return null;
            }
            finally
            {
                Dispose();
            }
        }
        public async Task<T> CrudTransAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new()
        {
            try
            {
                dbparams = new DynamicParameters();
                dbparams.PrepareParameter(parms);
                if (!_IsTransaction)
                    CreateConnection();

                return await db.QuerySingleOrDefaultAsync<T>(sp, dbparams, commandType: commandType, transaction: _IsTransaction? dbTra:null);
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Propiedad: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                _InfoTra.SetErrordb(errorMessage);
                _InfoRespuesta.SetErrorValidation(_InfoTra, sp);
                return new T();
            }
            catch (Exception ex)
            {
                _InfoRespuesta.SetErrorExep(ErrorType.Datos, ex, sp);
                return new T();
            }
            finally
            {
                Dispose();
            }
        }

        private  DataSet ConvertDataReaderToDataSet(IDataReader data)
        {
            DataSet ds = new DataSet();
            int i = 0;
            while (!data.IsClosed)
            {
                ds.Tables.Add("Table" + (i + 1));
                ds.EnforceConstraints = false;
                ds.Tables[i].Load(data);
                i++;
            }
            return ds;
        }
    }
}

