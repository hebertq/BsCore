﻿using HostService.Clases;
using HostService.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Repositorio.Extensions;
using Utilidades.ClasesGenericas;
using Utilidades.Interfaces;

namespace ApplicationWeb.Extensions
{
    public static class DependencyInjection
    {
        public static void AddAuthorizationPolicy(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            //services.AddSingleton<IAuthorizationHandler, ValuesCheckRouteParameterHandler>();
            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("BankRoutePolicy", valuesRoutePolicy =>
            //    {
            //        valuesRoutePolicy.Requirements.Add(new ValuesRouteRequirement());
            //    });
            //});
        }
        public static void AddApplicationServices(this IServiceCollection services)
        {
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(typeof(DependencyInjection).Assembly));
            services.AddAutoMapper(typeof(DependencyInjection).Assembly);
            services.AddDataRepositories();
            services.AddScoped<IUtilidades, Utilidad>();
            services.AddScoped<IUserService, UserService>();
            
        }       
    }
}
