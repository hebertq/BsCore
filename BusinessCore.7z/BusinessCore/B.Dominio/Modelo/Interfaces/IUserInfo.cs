﻿using Modelo.ClasesGenericas;
using System.Xml.Serialization;

namespace Modelo.Interfaces
{
    /// <summary>
    /// Información de la transacción actual de un usuario
    /// </summary>
    public interface IUserInfo
    {
        /// <summary>
        /// Nombre del usuario
        /// </summary>]
        [XmlIgnore()]
        string UserName { set; get; }
        /// <summary>
        /// Contraseña del Cliente
        /// </summary>
        [XmlIgnore()]
        string PassName { set; get; }
        /// <summary>
        /// Identificador del cliente
        /// </summary>
        [XmlIgnore()]
        decimal NoCliente { set; get; }
        /// <summary>
        /// Nombre de la base de datos del Emisor
        /// </summary>
        [XmlIgnore()]
        string EmisorDB { set; get; }
        /// <summary>
        /// Nombre del contexto
        /// </summary>
        [XmlIgnore()]
        InfoTipoContext ContextoDB { set; get; }
        /// <summary>
        /// Usuario para generar Token
        /// </summary>]
        [XmlIgnore()]
        string UserToken { set; get; }
        /// <summary>
        /// Inicializacion de variables
        /// </summary>
        void SetUserInfo(UserInfo info);
    }
}
