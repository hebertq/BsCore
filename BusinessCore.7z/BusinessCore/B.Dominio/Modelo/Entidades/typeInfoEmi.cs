﻿using System.Xml.Serialization;

namespace Modelo.Entidades
{
    public abstract class typeInfoEmi : CasoBizagi
    {
        [XmlElement(Order = 3)]
        public decimal NoCliente { set; get; } = 0;
        [XmlElement(Order = 4)]
        public decimal NoCtaIbs { set; get; } = 0;
        [XmlElement(Order = 5)]
        public decimal NoTarjeta { set; get; } = 0;
        [XmlElement(Order = 6)]
        public decimal NoCtaVasa { set; get; } = 0;
        [XmlElement(Order = 7)]
        public decimal NoTarVasa { set; get; } = 0;
        [XmlElement(Order = 8)]
        public int TipoGestion { set; get; } = 0;
        [XmlElement(Order = 9)]
        public int Oficial { set; get; } = 0;
        [XmlElement(Order = 10)]
        public string CCosto { set; get; } = string.Empty;

        [XmlElement(Order = 11)]
        public int Orden { set; get; } = 0;

        [XmlElement(Order = 12)]
        public string NoIban { set; get; } = string.Empty;

        [XmlElement(Order = 13)]
        public string NoProducto { set; get; } = string.Empty;

        [XmlElement(Order = 14)]
        public string Usuario { set; get; } = string.Empty;

        [XmlElement(Order = 15)]
        public decimal NoTarDevulta { set; get; } = 0;
    }
}

