﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entidades
{
    public enum EtapaTarjetas
    {
        Temporal = 0,
        Solicitud = 1,
        TrasladoBiz = 2,
        Impresion = 3,
        Desamarre = 4,
        Amarre = 5,
        ActivadoIBS = 6,
        ActivadoVAS = 7,
        Confirmado = 8,
        Liberada = 9,
        Abortado = 10,
        Baja = 11,
        FinCaso = 12,
        ProcesarBot = 13
    }
}
