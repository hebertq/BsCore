﻿using Core.ClasesGenericas;
using Dapper;
using System.Data;
using System.Reflection;

namespace Core.Estructuras
{
    public static class DapperExtension
    {      
        public static DynamicParameters WithSqlParam(this DynamicParameters dbparams, string paramName, object paramValue, DbType tipo)
        {
            dbparams.Add(paramName,paramValue,tipo);
            return dbparams;
        }

        public static void PrepareParameter(this DynamicParameters param, object parameters)
        {           
            if (parameters != null)
            {
                foreach (PropertyInfo prop in parameters.GetType().GetProperties())
                {
                    object value = prop.GetValue(parameters, null);
                    string name  = prop.Name;                   
                    DbType tipo;

                    if (value.GetType().GetProperty("TableName") != null)
                    {
                        tipo = DbType.Object;
                    }
                    else
                    {
                        tipo = TypeConvertor.ToDbType(prop.PropertyType);
                    }
                    param.WithSqlParam(name, value, tipo);
                }
            }
        }     
    }
}
