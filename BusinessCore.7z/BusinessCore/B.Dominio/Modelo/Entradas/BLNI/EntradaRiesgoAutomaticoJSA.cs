﻿using Modelo.Entradas.BLHNI;
using System.Collections.Generic;


namespace Modelo.Entradas.BLNI
{
    public class EntradaRiesgoAutomaticoJSA:BaseRiesgoCliente
    {
        public string PaisConstitucion { set; get; } = "";
        public List<CuentaRiesgo> LCuentaRiesgos { set; get; } = new List<CuentaRiesgo>();
        public List<FirmantesPep> Firmantes { set; get; } = new List<FirmantesPep>();
        public List<SociosPep> Socios { set; get; } = new List<SociosPep>();
    }
}
