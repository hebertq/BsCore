﻿using MediatR;
using Modelo.Admin;
using Modelo.Interfaces;

namespace ApiApplication.Features.Admin.Commands
{
    public record AddTokenUserCommand(RefreshToken token) : IRequest<IResponse>;
}
