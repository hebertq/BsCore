﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using System.Reflection;
using System.Threading.Tasks;
using System;
using Utilidades.Interfaces;
using Modelo.Salida;
using Repositorio.Interfaces;
using System.Data;

namespace Repositorio.Clases
{
    internal class OdooRepositorio : RepositorioBase, IOdooRepositorio
    {
        public OdooRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util)
        {
            _dapper.dbcontex = InfoContextSQL.Odoo;
            _dapper._dbTipo  = TipoDB.NPGDB;
        }

        public async Task<IListResponse<ComboDatos>> GetAllEmpleados()
        {
            IListResponse<ComboDatos> response = new ListResponse<ComboDatos>();
            try
            {
                string func = "select id,name,pin key from public.hr_employee";
                var result  = await _dapper.GetAllAsync<ComboDatos>(func, null,CommandType.Text);
                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else                  
                    response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
    }
}
