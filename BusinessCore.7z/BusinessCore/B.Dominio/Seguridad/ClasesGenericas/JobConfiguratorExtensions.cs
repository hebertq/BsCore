﻿using Microsoft.Extensions.Configuration;
using Modelo.ClasesGenericas;
using Quartz;
using System;
using System.Linq;

namespace Seguridad.ClasesGenericas
{
    public static class JobConfiguratorExtensions
    {
        public static void AddJobAndTrigger<T>(
                    this IServiceCollectionQuartzConfigurator q,
                    IConfiguration config)
                    where T : IJob
        {
            AppConfig options = config.Get<AppConfig>();

            string jobName = typeof(T).Name;           
            var job        = options.Job.JobBpmConfig.Where(x=>x.name == jobName).First();

            if (string.IsNullOrEmpty(job.config))
            {
                throw new Exception($"No se encontro la configuracion del Job: {jobName}");
            }

            // configure jobs with code
            var jobKey = new JobKey(jobName,job.group);
            q.AddJob<T>(j => j
                .StoreDurably()
                .WithIdentity(jobKey)
                .WithDescription(job.description)
            );

            q.AddTrigger(opts => opts
                .ForJob(jobKey)
                .WithIdentity(jobName + "-trigger")
                .WithCronSchedule(job.config)
                .WithDescription("Creación de trigger para el job: "+ jobName));

        }
    }
}

