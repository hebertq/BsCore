﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using Repositorio.Extensions;
using BPMLogger;
using Utilidades.ClasesGenericas;
using Utilidades.Interfaces;

namespace ApiApplication.Extensions
{
    public static class DependencyInjection
    {
        public static void AddAuthorizationPolicy(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            //services.AddSingleton<IAuthorizationHandler, ValuesCheckRouteParameterHandler>();
            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("BankRoutePolicy", valuesRoutePolicy =>
            //    {
            //        valuesRoutePolicy.Requirements.Add(new ValuesRouteRequirement());
            //    });
            //});
        }
        public static void AddApplicationServices(this IServiceCollection services)
        {
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(typeof(DependencyInjection).Assembly));
            services.AddAutoMapper(typeof(DependencyInjection).Assembly);
            services.AddDataRepositories();
            services.AddScoped<IUtilidades, Utilidad>();
            services.AddScoped<ILoggerBMP, LoggerBMP>();
        }
        public static void AddApplicationSuagger(this IServiceCollection services)
        {
            #region Swagger and versioning services
            services.AddSwaggerGen(options =>
            {
                options.CustomSchemaIds(type => type.FullName);
                options.EnableAnnotations();

                // integrate xml comments
                var currentAssembly = Assembly.GetExecutingAssembly();
                var xmlDocs = currentAssembly.GetReferencedAssemblies()
                .Union(new AssemblyName[] { currentAssembly.GetName() })
                .Select(a => Path.Combine(Path.GetDirectoryName(currentAssembly.Location), $"{a.Name}.xml"))
                .Where(f => File.Exists(f)).ToArray();

                Array.ForEach(xmlDocs, (d) =>
                {
                    options.IncludeXmlComments(d);
                });

                options.DocumentFilter<RemoveDefaultApiVersionRouteDocumentFilter>();
               // options.ParameterFilter<EventNameParameterFilter>();
                options.OperationFilter<RemoveQueryApiVersionParamOperationFilter>();
               // options.DocumentFilter<EventPublishDocumentFilter>();
            });

            #endregion
        }
    }
}
