﻿
namespace Modelo.Entidades
{
    public class InfoTDCta : typeInfoEmi
    {
        public string ErrorMsj { set; get; } = string.Empty;
        public EtapaTarjetas IdEstado { set; get; }
        public int IdCtrl { set; get; } = 1;
        public decimal NoCtaIbs2 { set; get; } = 0;
        public decimal NoCtaIbs3 { set; get; } = 0;
        public int IdCaseParent { set; get; } = 0;
    }
}
