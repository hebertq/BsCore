﻿using Core.ClasesGenericas;
using Microsoft.Extensions.Configuration;
using Modelo.ClasesGenericas;
using Npgsql;
using System;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Estructuras
{
    public class NpgContext : DatabaseProvider
    {
        public NpgContext(IConfiguration configuration) : base(configuration) { }

        public override string GetConnectionString(InfoContextSQL name)
        {
            var contex = _config.ConnectionStrings.Contexto.Where(x => x.ContexName == name.ToString()).FirstOrDefault();
            string _connectionString;
            if (contex == null)
                throw new InvalidOperationException("La conección: " + name.ToString() + " a la base de datos no esta configurada");
            else
                _connectionString = string.Format("HOST = {0}; Database = {1};User ID={2}; Password={3}", contex.IpServer, contex.Database, contex.UserId, contex.PassId);

            return _connectionString;
        }

        public override DbProviderFactory Factory => NpgsqlFactory.Instance;
        public async Task<IDbConnection> CreateConnection(InfoContextSQL con)
        {
            return await GetOpenConnection(con);
        }
    }
}
