﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    // <summary>
    /// Objeto retornado por los procedimientos alamacenados desde la base de datos
    /// </summary>
    public class ErrorMjsBd
    {
        /// <summary>
        /// variable que determina si la transaccion provoco un error
        /// </summary>
        public bool IsError { set; get; }
        /// <summary>
        /// código de error
        /// </summary>
        public int CodeError { set; get; }
        /// <summary>
        /// Estado del Error
        /// </summary>
        public int ErrState { set; get; }
        /// <summary>
        /// mensaje de error
        /// </summary>
        public string MjsError { set; get; }
        /// <summary>
        /// identificador devuelto
        /// </summary>
        public int CodId { set; get; }
    }
}
