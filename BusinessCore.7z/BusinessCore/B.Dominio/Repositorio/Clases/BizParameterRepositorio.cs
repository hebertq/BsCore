﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Entradas.BLNI;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using Repositorio.Interfaces;
using System;
using System.Reflection;
using System.Threading.Tasks;
using Utilidades.Interfaces;

namespace Repositorio.Clases
{
    public class BizParameterRepositorio : RepositorioBase, IBizParameterRepositorio
    {
        public BizParameterRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util)
        {
            _dapper.dbcontex = InfoContextSQL.BZPARAMETROS;
        }
        public async Task<IResponse> AddCalificacionRiesgo(typecalificacion request)
        {
            IResponse response = new ErrorResponse();
            try
            {
                string tablxml = _Util.ToXml(request);
                var data = await _dapper.GetAsync<ErrorMjsBd>("dbo.usp_BullUpdRiesgos", new { pix_riesgo = tablxml });
                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                {
                    if (data.IsError)
                        response.Respuesta.SetErrorDb(data, "usp_BullUpdRiesgos");
                }
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }
            return response;
        }
    }
}
