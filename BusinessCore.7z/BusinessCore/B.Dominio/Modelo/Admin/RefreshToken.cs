﻿using System;
using System.Collections.Generic;

namespace Modelo.Admin
{
    public class RefreshToken
    {
        public int Token_Id { get; set; }
        public int User_Id { get; set; }
        public string Token { get; set; }
        public DateTime Expiry_Date { get; set; }
    }
}
