﻿using Modelo.ClasesGenericas;
using Newtonsoft.Json;
using System;
using System.Linq;

namespace Modelo.Entradas
{
    public class EventConfig
    {
        [JsonIgnore]
        public Bancos pais { set; get; } = Bancos.BLHN;
        [JsonIgnore]
        public string evento { set; get; } = "Nombre del evento";
        public TipoServicio servicio { set; get; } = TipoServicio.CMN;
        public string scheduler { set; get; } = "Schedulers.Nombre";
        public string triggersname { set; get; } = "Triggers.Nombre";
        [JsonIgnore]
        public string triggersdesc { set; get; } = "Procesamiento de eventos de servicios ";
        public TipoEvento tipoevento { set; get; } = TipoEvento.Proceamiento;
        [JsonIgnore]
        public string eventodesc { set; get; } = "Evento para procear servicio ";
        public int nomaxcasos { set; get; } = 5;
        public int noreintentos { set; get; } = 2;

        public TipoServicio getServicio()
        {
            string strservicio = Enum.GetNames(typeof(TipoServicio)).Where(x => evento.Contains(x)).First();
            return Enum.Parse<TipoServicio>(strservicio);
        }

        public Bancos getBanco()
        {
            string strbanco = Enum.GetNames(typeof(Bancos)).Where(x => evento.Contains(x)).First();
            return Enum.Parse<Bancos>(strbanco);
        }

        public void setData(string nombreevento)
        {
            evento = nombreevento;
            pais = getBanco();
            servicio = getServicio();
            triggersdesc = $"{triggersdesc}{servicio} para el banco {pais}";
            eventodesc = $"{eventodesc}{servicio} para el banco {pais}";
        }
        public void setJobData()
        {
        }
        public void setRemoveData()
        {
        }
    }
}
