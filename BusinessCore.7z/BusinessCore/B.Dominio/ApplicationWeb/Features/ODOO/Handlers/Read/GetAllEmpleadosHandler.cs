﻿using ApplicationWeb.Features.ODOO.Queries;
using MediatR;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Modelo.Salida;
using Repositorio.Interfaces;


namespace ApplicationWeb.Features.ODOO.Handlers.Read
{
    public class GetAllEmpleadosHandler : IRequestHandler<GetAllEmpleadosActivosQuery, IListResponse<ComboDatos>>
    {
        private readonly IOdooRepositorio _odoo;
        public GetAllEmpleadosHandler(IOdooRepositorio odoo)
        {
            _odoo = odoo;
        }
        public async Task<IListResponse<ComboDatos>> Handle(GetAllEmpleadosActivosQuery request, CancellationToken cancellationToken)
        {
            IListResponse<ComboDatos> response = new ListResponse<ComboDatos>();
            try
            {
                response = await _odoo.GetAllEmpleados();
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, "JobsServices.Publish");
            }

            return await Task.FromResult(response);
        }
    }
}
