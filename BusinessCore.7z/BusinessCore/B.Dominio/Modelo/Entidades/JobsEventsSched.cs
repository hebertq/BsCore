﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entidades
{
    public class JobsEventsSched
    {
        public int id { set; get; } = 0;
        public string tipotrigg { set; get; }
        public string jobname { set; get; }
        public int prioridad { set; get; } = 0;
        public List<DetEventsSched> eventos { set;get; } = new List<DetEventsSched>();
    }

    public class DetEventsSched
    {
        public int id { set; get; } = 0;
        public int eventid { set; get; }= 0;
        public string casenumber { set; get; }
        public byte[] jobdata { set; get; }
    }
}
