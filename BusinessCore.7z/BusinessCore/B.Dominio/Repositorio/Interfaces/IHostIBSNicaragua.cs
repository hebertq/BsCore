﻿using Modelo.ClasesGenericas;
using Modelo.Entradas;
using Modelo.Entradas.BLNI;
using Modelo.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IHostIBSNicaragua
    {
        Task<ISingleResponse<responseDataString>> ObtenerRiesgoxActividad(string actividadEconomica);
        Task<ISingleResponse<int>> ObtenerCalificacionxRiesgo(string riesgoAutomatico);
        Task<ISingleResponse<int>> ObtenerCalificacionPnpPepAltoRiesgoRelacionado(decimal NoCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionxPais(string sPais);
        Task<ISingleResponse<int>> ObtenerCalificacionxDepartamento(string sDep);
        Task<ISingleResponse<int>> ObtenerCalificacionxActividadSinRiesgoAsociado(string sActividad);
        Task<ISingleResponse<int>> ObtenerCalificacionxProductoCtas(List<CuentaRiesgo> LCuentaRiesgos);
        Task<ISingleResponse<int>> ObtenerCalificacionBACKTOBACK(decimal noCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionTCPREPAGO(decimal noCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionTCDEBITO(decimal noCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionCrcFideicomisos(decimal noCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionFIDEICOMISOS(decimal noCliente);
        Task<IListResponse<PrestamosAsociados>> ObtenerCalificacionPRESTAMOS(decimal noCliente);
        Task<ISingleResponse<int>> ObtenerCalificacionCERTIFICADODTO(decimal noCliente);
        Task<ISingleResponse<decimal>> ObtenerTasaCambio(decimal noCliente, string sTipo);
        Task<ISingleResponse<int>> ObtenerCalificacionxRiesgoPLD(string Riesgo, string Tipo);
        Task<ISingleResponse<int>> ObtenerCalificacionxRiesgoManual(decimal ciente);
    }
}
