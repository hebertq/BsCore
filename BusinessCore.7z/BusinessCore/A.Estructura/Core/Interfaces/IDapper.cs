﻿using Modelo.ClasesGenericas;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IDapper : IDisposable
    {
        InfoContextSQL dbcontex { set; get; }
        Task<T> GetAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new();
        Task<List<T>> GetAllAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new();
        Task Execute(string sp, object parms, CommandType commandType = CommandType.StoredProcedure);
        Task<T> CrudTransAsync<T>(string sp, object parms, CommandType commandType = CommandType.StoredProcedure) where T : class, new();
        Task<DataSet> QueryMultiple(string sp, object parms, CommandType commandType = CommandType.StoredProcedure);
        void Transaction();
        void CommitTran();
        void RollbackTran();
        IDbConnection ConnecDb { get; }
        void CreateConnection();
        TipoDB _dbTipo { set; get; }
        ResultadoGenerico _InfoRespuesta { set; get; }
    }
}
