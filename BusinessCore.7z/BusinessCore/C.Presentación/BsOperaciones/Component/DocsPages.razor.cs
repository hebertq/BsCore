﻿using Microsoft.AspNetCore.Components;
using TabBlazor.Services;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BsOperaciones.Component
{
    public partial class DocsPages : ComponentBase
    {
        [Inject] public TablerService TablerService { get; set; }
        [Parameter] public string Title { get; set; }
        [Parameter] public RenderFragment ChildContent { get; set; }
        [Parameter] public RenderFragment Description { get; set; }
        [Parameter] public Type ComponentType { get; set; }
        [Parameter] public string PolicyConstants { get; set; }
        [Parameter] public string IdPage { get; set; }
        private async Task NavigateTo(CodeSnippet codeSnippet)
        {
            await TablerService.ScrollToFragment(codeSnippet.Id.ToString());
        }

        public List<CodeSnippet> CodeSnippets = new List<CodeSnippet>();
        public void AddCodeSnippet(CodeSnippet codeSnippet)
        {
            if(codeSnippet != null)
                 CodeSnippets.Add(codeSnippet);

            StateHasChanged();
        }   

        public void RemoveCodeSnippet(CodeSnippet codeSnippet)
        {
            CodeSnippets.Remove(codeSnippet);
            StateHasChanged();
        }
    }
}

