﻿using Core.ClasesGenericas;
using Microsoft.Extensions.Configuration;
using Modelo.ClasesGenericas;
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Estructuras
{  
    public class SqlContext : DatabaseProvider
    {
        public SqlContext(IConfiguration configuration) : base(configuration){ }
        
        public override string GetConnectionString(InfoContextSQL name)
        {
            var contex = _config.ConnectionStrings.Contexto.Where(x => x.ContexName == name.ToString()).FirstOrDefault();
            string _connectionString;
            if (contex == null)
                throw new InvalidOperationException("La conección: "+ name.ToString()+" a la base de datos no esta configurada");
            else
                _connectionString = string.Format("Data Source={0};initial catalog={1};User ID={2};password={3}; Integrated Security=true; Encrypt=false", contex.IpServer, contex.Database, contex.UserId, contex.PassId);
            
            return _connectionString;
        }

        public override DbProviderFactory Factory => SqlClientFactory.Instance;
        public async Task<IDbConnection> CreateConnection(InfoContextSQL con)
        {
            return await GetOpenConnection(con);
        }
    }
}
