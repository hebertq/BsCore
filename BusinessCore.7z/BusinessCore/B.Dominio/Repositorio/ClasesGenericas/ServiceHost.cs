﻿using Modelo;
using Modelo.ClasesGenericas;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Utilidades.Interfaces;

namespace Repositorio.ClasesGenericas
{
    public abstract class ServiceHost
    {
        private readonly HttpClient _httpClient;
        protected IUtilidades _Util;
        public ServiceHost(IUtilidades util)
        {
            _httpClient = new HttpClient();
            _Util = util;
            addHeaders();
        }

        public async Task<Message<T>> GetAsync<T>(Uri requestUrl)
        {
            Message<T> Result = new Message<T>();
            try
            {
                var response = await _httpClient.GetAsync(requestUrl, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();
                var data = await response.Content.ReadAsStringAsync();
                Result.Data = _Util.ObtenerRegistro<T>(data);
            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, "HttpClient");
            }

            return Result;
        }


        /// <summary>
        /// Common method for making POST calls
        /// </summary>
        public async Task<Message<T>> PostAsync<T>(Uri requestUrl, T content)
        {
            Message<T> Result = new Message<T>();
            try
            {
                var response = await _httpClient.PostAsync(requestUrl.ToString(), _Util.CreateHttpContent<T>(content));
                response.EnsureSuccessStatusCode();
                var data = await response.Content.ReadAsStringAsync();
                Result.Data = _Util.ObtenerRegistro<T>(data);
            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, "HttpClient");
            }

            return Result;
        }
        public async Task<Message<T1>> PostAsync<T1, T2>(Uri requestUrl, T2 content)
        {
            Message<T1> Result = new Message<T1>();
            try
            {
                var response = await _httpClient.PostAsync(requestUrl.ToString(), _Util.CreateHttpContent<T2>(content));
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    response.EnsureSuccessStatusCode();
                    var data = await response.Content.ReadAsStringAsync();
                    Result.Data = _Util.ObtenerRegistro<T1>(data);
                }
                else
                {
                    string status = response.StatusCode.ToString();
                    Result.SetErroAcces("Error al aceder a " + requestUrl.ToString(), "HttpClient", status);
                }

            }
            catch (CoreException ex)
            {
                Result.SetErrorExep(ex, "HttpClient");
            }

            return Result;
        }

        public Uri CreateRequestUri(string relativePath, string queryString = "")
        {
            string path = string.Format(System.Globalization.CultureInfo.InvariantCulture, relativePath);
            var endpoint = new Uri(new Uri(_Util.BaseUrlApiLog), path);
            var uriBuilder = new UriBuilder(endpoint);
            uriBuilder.Query = queryString;
            return uriBuilder.Uri;
        }

        private void addHeaders()
        {
            _httpClient.DefaultRequestHeaders.Remove("userIP");
            _httpClient.DefaultRequestHeaders.Add("userIP", "192.168.1.1");
            _httpClient.BaseAddress = new Uri(_Util.BaseUrlApiLog);
            _httpClient.DefaultRequestHeaders.Accept.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            _httpClient.DefaultRequestHeaders.ConnectionClose = false;
            //_httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _UserInfo.Token.AccessToken == string.Empty || _UserInfo.Token.AccessToken == null ? "" : _UserInfo.Token.AccessToken);
        }
    }
}


