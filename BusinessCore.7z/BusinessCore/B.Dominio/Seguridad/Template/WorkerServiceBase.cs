﻿using BPMLogger;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Modelo.ClasesGenericas;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Utilidades.Interfaces;
using static Modelo.ClasesGenericas.AppConfig;

namespace Seguridad.Template
{
    public class WorkerServiceBase : IHostedService, IDisposable
    {
        #pragma warning disable CA1416 // Validate platform compatibility
        private Timer _timer;
        private static object _lock = new object();
        private readonly IUtilidades _Util;
        private readonly ILoggerBMP _Log;
        private readonly AppSettingsSW _ConfigService;
        public LogJob _SegProc;
        public string BathName = "";
        public string ServiceName = "";

        public WorkerServiceBase(IUtilidades Util, ILoggerBMP Log, IConfiguration Conf)
        {
            Util.Options = Conf.Get<AppConfig>();
            _Util = Util;
            _ConfigService = _Util.ConfigService;
            _Log = Log;
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            try
            {
                if (!EventLog.SourceExists(BathName))
                {
                    EventLog.CreateEventSource(BathName, BathName);
                    EventLog.WriteEntry(BathName, "Inicio proceso " + ServiceName, EventLogEntryType.Information);
                }
                else
                    EventLog.WriteEntry(BathName, "Inicio proceso " + ServiceName, EventLogEntryType.Information);
                var timpo = TimeSpan.FromMinutes(_ConfigService.TiempoEspera);

                _timer = new Timer(DoWork, null, TimeSpan.Zero, TimeSpan.FromMinutes(_ConfigService.TiempoEspera));
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry(BathName, ex.Message, EventLogEntryType.Error);
                EventLog.WriteEntry(BathName, "Servicio detenido, error inicializando los datos", EventLogEntryType.Error);
                Environment.Exit(0);
            }

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _timer?.Change(Timeout.Infinite, 0);
            EventLog.WriteEntry(BathName, "El servicio se ha detenido manualmente", EventLogEntryType.Warning);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }

        private void DoWork(object state)
        {
            int nHoraActual = DateTime.Now.Hour;
            if (nHoraActual >= _ConfigService.HoraInicio && nHoraActual <= _ConfigService.HoraFin) //Hora de Ejecucion del Servicio
            {
                if (Monitor.TryEnter(_lock))
                {
                    try
                    {
                        ExecuteJob();
                    }
                    catch (Exception ex)
                    {
                        EventLog.WriteEntry(BathName, "Servicio detenido por error ExecuteJob.", EventLogEntryType.Error);
                        EventLog.WriteEntry(BathName, ex.Message, EventLogEntryType.Error);
                    }
                    finally
                    {
                        Monitor.Exit(_lock);
                    }
                }
            }
        }

        /// <SUMMARY>
        /// Ejecucion por defecto 
        /// </SUMMARY>
        /// <RETURNS></RETURNS>
        protected virtual void ExecuteJob()
        {
        }
        #pragma warning restore CA1416 // Validate platform compatibility
    }
}
