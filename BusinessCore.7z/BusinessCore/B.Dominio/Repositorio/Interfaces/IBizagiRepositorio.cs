﻿using Modelo.Entidades;
using Modelo.Interfaces;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IBizagiRepositorio
    {
        Task<IListResponse<InfoTDCta>> GetAllTarjetasEstado(int estado);
    }
}
