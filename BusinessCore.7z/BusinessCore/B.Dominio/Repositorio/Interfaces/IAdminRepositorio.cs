﻿using Modelo.Admin;
using Modelo.Interfaces;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IAdminRepositorio
    {
        Task<IListResponse<User>> GetAllUsers();
        Task<IListResponse<RefreshToken>> GetAllRefreshTokensByUserid(int id);
        Task<IResponse> AddRefreshTokensByUserid(RefreshToken token);
    }
}
