﻿using Modelo.ClasesGenericas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entradas
{
    public class GenericSoapBZI
    {
        public Bancos banco {  get; set; }
        public TipoSoapBZI tipo { get; set; }
        public string xpath { get; set; }
    }
}
