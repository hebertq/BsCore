﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entradas
{
    public class ResquestFindClient
    {
        public string Identificacion { set; get; }
        public decimal NoCliente { set; get; }
        public string Nombre{ set; get; }
}
}
