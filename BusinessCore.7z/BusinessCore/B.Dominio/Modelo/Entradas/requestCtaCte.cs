﻿using Modelo.ClasesGenericas;
using Modelo.Validaciones;

namespace Modelo.Entradas
{
    public class requestCteActEconomica
    {
        public string ICHRACTIVIDADECONOMICA { set; get; }
    }

    public class requestCteCalRiesgo
    {
        public string OCHRRIESGO { set; get; }
    }

    public class requestCte
    {
        public decimal IDECCUSCUN { set; get; }
    }

    public class responseDataString
    {
        public string Data { set; get; }
    }

    public class requestDpto
    {
        public string ICHRDEPARTAMENTO { set; get; }
    }
}
