﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Salida
{
    public class ComboDatos
    {
        int id { get; set; } = 1;
        string name { get; set; } = string.Empty;
        int key { get; set; } = 1;
    }
}
