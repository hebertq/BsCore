﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Entidades;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using Repositorio.Interfaces;
using System;
using System.Reflection;
using System.Threading.Tasks;
using Utilidades.Interfaces;

namespace Repositorio.Clases
{
    public class BizagiRepositorio: RepositorioBase, IBizagiRepositorio
    {
        public BizagiRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util) { }

        public async Task<IListResponse<InfoTDCta>> GetAllTarjetasEstado(int estado)
        {
            IListResponse<InfoTDCta> response = new ListResponse<InfoTDCta>();
            try
            {
                var result = await _dapper.GetAllAsync<InfoTDCta>("dbo.usp_GetTarjetaEstado", new { pEstado = estado });
                response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
    }
}
