﻿
namespace Modelo.Salida
{
    public class CalificacionRiesgoCliente
    {
        public string CRC { get; set; } = "0";
        public string LA { get; set; } = "0";
        public string FT { get; set; } = "0";
        public string FP { get; set; } = "0";
    }
}
