﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entradas.BLNI
{
    public class CuentaRiesgo
    {
        public string TipoCuenta { set; get; } = "";
        public string Clasificacion { set; get; } = "";
        public string Gl { set; get; } = "";
    }
}
