﻿using System;

namespace Modelo.Entidades
{
    public class Cliente
    {
        public string NombreCompleto = "";
        public string Sucursal = "";
        public string OficialCuenta;
        public string SegundoOficialCuenta;
        public decimal NoCliente = 0;
        public DateTime? FechaIniRelacion = null;

        public string PaisNacionalidad = "";
        public string Direccion1 = string.Empty;
        public string Direccion2 = string.Empty;
        public string Direccion3 = string.Empty;
        public string Direccion4 = string.Empty;
        public string Direccion = "";
        public string DireccionPostal1 = string.Empty;
        public string DireccionPostal2 = string.Empty;
        public string DireccionPostal3 = string.Empty;
        public string DireccionPostal4 = string.Empty;
        public string DireccionPostal = "";
        public string Sector = "";
        public string ActividadEconomica = "";

        public string PaisRiesgo = "";
        public string TipoCliente = "";
        public decimal GrupoCliente = 0;
        public DateTime? FechaActualizacion;

        //public ClienteNAT ClienteNAT;
        //public List<ReferenciaComercial> ReferenciasComerciales = new List<ReferenciaComercial>();
        //public List<ReferenciaBancaria> ReferenciasBancarias = new List<ReferenciaBancaria>();
        //public string InstruccionesCliente = "";

        //public BnetCliente BnetCliente;
        //public BnetTransInter BnetTransInter;
        //public List<BnetUsuario> BnetUsuarios = new List<BnetUsuario>();

        //public List<Firmante> Firmantes = new List<Firmante>();

        //public List<CuentaPreregistrar> BnetCuentasTercero = new List<CuentaPreregistrar>();
        //public List<CuentaPreregistrar> BnetCuentasTerceroOtroBanco = new List<CuentaPreregistrar>();
        //public List<TarjetaPreregistrar> BnetTarjetasTercero = new List<TarjetaPreregistrar>();
        //public List<CuentaPropia> CuentasPropias = new List<CuentaPropia>();
        //public List<CuentaMancomunada> CuentasMancomunadas = new List<CuentaMancomunada>();
        //public List<InstruccionEspecial> InstruccionesEspeciales = new List<InstruccionEspecial>();
        //public string Estado = "";
        //public string Aprobado = "";

        //public ResultadoCDP resultadoCDP = new ResultadoCDP();
        //public List<InfoClientePlanAhorro> PlanesDeAhorros = new List<InfoClientePlanAhorro>();

        //public List<EnviaTransferenciaInternacional> EnviaTransferenciaInternacionales = new List<EnviaTransferenciaInternacional>();
        //public List<RecibeTransferenciaInternacional> RecibeTransferenciaInternacionales = new List<RecibeTransferenciaInternacional>();
    }
}
