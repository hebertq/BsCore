﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entidades
{
    public class InfoClientes
    {
        public string Telefono { set; get; } = string.Empty;
        public string Cedula { set; get; } = string.Empty;
        public string Nombre { set; get; } = string.Empty;
        public string Apellido { set; get; } = string.Empty;

    }
}
