﻿using MediatR;
using Modelo.Admin;
using Modelo.Interfaces;

namespace ApiApplication.Features.Admin.Queries
{
    public record GetAllRefreshTokensByUseridQuery(int id) : IRequest<IListResponse<RefreshToken>>;
}
