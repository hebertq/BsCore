﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seguridad.Constants
{
    public class JobsConstants
    {
        public static readonly int WaitInterval = 2; // Seconds
        public static readonly string Group     = "BPM"; // Can be anything
    }
}
