﻿using Microsoft.Extensions.Configuration;
using Modelo.ClasesGenericas;
using System;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;

namespace Core.ClasesGenericas
{
    public abstract class DatabaseProvider : IDisposable
    {
        private readonly IConfiguration _configuration;
        public AppConfig     _config;
        private DbConnection _connection;
        public DatabaseProvider(IConfiguration configuration)
        {
            _configuration = configuration;
            _config = _configuration.Get<AppConfig>();
        }
        public abstract DbProviderFactory Factory { get; }

        public virtual void Dispose()
        {
            _connection?.Dispose();
            _connection = null;
        }
        public abstract string GetConnectionString(InfoContextSQL name);

        public async Task<DbConnection> GetOpenConnection(InfoContextSQL _ContexName)
        {
            _connection = Factory.CreateConnection();
            _connection.ConnectionString = GetConnectionString(_ContexName);

            await _connection.OpenAsync();
            if (_connection.State != ConnectionState.Open) 
                throw new InvalidOperationException("la coneccioón debe estar abierta!");

            return _connection;
        }
    }
}


