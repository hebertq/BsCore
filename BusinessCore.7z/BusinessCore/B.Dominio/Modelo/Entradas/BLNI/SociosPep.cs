﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Entradas.BLNI
{
    public class SociosPep
    {
        public bool Pnp { set; get; } = false;
        public int NoCliente { set; get; } = 0;
        public bool Pep { set; get; } = false;   
        public int AnioInicio { get; set; } = 0;
        public int AnioFinaliza { get; set; } = 0;
    }
}
