﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Entidades;
using Modelo.Entradas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using Repositorio.Interfaces;
using System;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Utilidades.Interfaces;

namespace Repositorio.Clases
{
    public class JobsRepository : RepositorioBase, IJobsRepository
    {
        public JobsRepository(IDapper dapper, IUtilidades util) : base(dapper, util) 
        {
            _dapper.dbcontex = InfoContextSQL.BZPARAMETROS;
        }

        public async Task<IResponse> AddEventsJob(BaseEvents request) 
        {          
            IResponse response = new ErrorResponse();
            try
            {
                string tablxml = _Util.ToXml(request);
                var data =  await _dapper.GetAsync<ErrorMjsBd>("dbo.usp_AddEventos", new { pix_eventoxml = tablxml });
                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                {
                    if (data.IsError)
                        response.Respuesta.SetErrorDb(data, "AddEventsJob");
                }              
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            response.SetObjet();
            return response;
        }

        public async Task<IResponse> SetProcessingJobId(int request)
        {
            IResponse response = new ErrorResponse();
            try
            {
                var data = await _dapper.GetAsync<ErrorMjsBd>("dbo.usp_SetProcessingJobId", new { pii_jobid = request });
                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                {
                    if (data.IsError)
                        response.Respuesta.SetErrorDb(data, "AddEventsJob");
                    else if (data.CodId > 0)
                        response.Respuesta.CodError = data.CodId;
                    else
                        response.Respuesta.CodError = 0;
                }
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            response.SetObjet();
            return response;
        }
        
        public async Task<IListResponse<JobsEventsSched>> GetEventsJobSched(string Sched)
        {
            IListResponse<JobsEventsSched> response = new ListResponse<JobsEventsSched>();
            try
            {
                DataSet multi = await _dapper.QueryMultiple("dbo.usp_AddProgSched", new { piv_name = Sched });
                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                {
                    var error = _Util.ConvertTo<ErrorMjsBd>(multi.Tables[0]).FirstOrDefault();
                    if (error.IsError)
                        response.Respuesta.SetErrorDb(error, "GetEventsJobSched");
                    else
                    {
                        var master = _Util.ConvertTo<JobsEventsSched>(multi.Tables[1]);
                        var detail = _Util.ConvertTo<DetEventsSched>(multi.Tables[2]); 
                        foreach(var m in master)
                        {
                            m.eventos = detail.Where(x => x.id == m.id).ToList();
                        }
                        response.Model = master.ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }
            return response;
        }
    }
}
