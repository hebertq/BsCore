﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public enum InfoContextDB2
    {
        ///<summary>
        /// Contexto para AS400 Nicaragua
        /// </summary>
        AS400NI = 1,
        ///<summary>
        /// Contexto para AS400 Costa Rica
        /// </summary>
        AS400CR = 2,
        ///<summary>
        /// Contexto para AS400 Honduras
        /// </summary>
        AS400HN = 3,
        ///<summary>
        /// Contexto para AS400 Dominicana
        /// </summary>
        AS400RD = 4
    }
}
