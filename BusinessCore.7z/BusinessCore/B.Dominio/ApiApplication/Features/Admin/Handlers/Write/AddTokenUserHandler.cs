﻿using ApiApplication.Features.Admin.Commands;
using ApiApplication.Features.Admin.Queries;
using MediatR;
using Modelo.Admin;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiApplication.Features.Admin.Handlers.Write
{
    public class AddTokenUserHandler : IRequestHandler<AddTokenUserCommand, IResponse>
    {
        private readonly IAdminRepositorio _Adm;
        public AddTokenUserHandler(IAdminRepositorio adm) { _Adm = adm; }
        public async Task<IResponse> Handle(AddTokenUserCommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(await _Adm.AddRefreshTokensByUserid(request.token));
        }
    }
}
