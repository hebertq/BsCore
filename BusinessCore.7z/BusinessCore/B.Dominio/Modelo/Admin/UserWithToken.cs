﻿namespace Modelo.Admin
{
    public class UserWithToken : User
    {      
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public void SetData(User user)
        {
            this.User_Id       = user.User_Id;
            this.Email_Address = user.Email_Address;
            this.First_Name    = user.First_Name;
            this.Middle_Name   = user.Middle_Name;
            this.Last_Name     = user.Last_Name;
            this.Pub_Id        = user.Pub_Id;
            this.Hire_Date     = user.Hire_Date;
        }
    }
}
