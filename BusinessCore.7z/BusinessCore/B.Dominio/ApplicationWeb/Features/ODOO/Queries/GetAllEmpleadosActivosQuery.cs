﻿using MediatR;
using Modelo.Entidades;
using Modelo.Interfaces;
using Modelo.Salida;

namespace ApplicationWeb.Features.ODOO.Queries
{
    public record GetAllEmpleadosActivosQuery() : IRequest<IListResponse<ComboDatos>>;
}
