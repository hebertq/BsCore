﻿using Modelo.Entradas.BLHNI;
using System.Collections.Generic;

namespace Modelo.Entradas.BLNI
{
    public class EntradaRiesgoAutomaticoNat: BaseRiesgoCliente
    {
        public string PaisProcedencia { set; get; } = "";
        public string Departamento { set; get; } = "";
        public List<CuentaRiesgo> LCuentaRiesgos { set; get; } = new List<CuentaRiesgo>();
        public string TipoJsa { set; get; } = "";
        public bool Pep { set; get; } = false;
        public bool Pnp { set; get; } = false;
        public int AnioInicio { get; set; } = 0;
        public int AnioFinaliza { get; set; } = 0;
        public List<FirmantesPep> Firmantes { set; get; } = new List<FirmantesPep>();
    }
}
