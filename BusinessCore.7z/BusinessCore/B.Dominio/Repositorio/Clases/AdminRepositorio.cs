﻿using Core.Interfaces;
using Modelo.ClasesGenericas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using System.Data;
using System.Reflection;
using System.Threading.Tasks;
using System;
using Utilidades.Interfaces;
using Modelo.Admin;
using Repositorio.Interfaces;

namespace Repositorio.Clases
{
    internal class AdminRepositorio : RepositorioBase, IAdminRepositorio
    {
        public AdminRepositorio(IDapper dapper, IUtilidades util) : base(dapper, util)
        {
            _dapper.dbcontex = InfoContextSQL.BZPARAMETROS;
            _dapper._dbTipo  = TipoDB.SQLDB;
        }

        public async Task<IListResponse<User>> GetAllUsers()
        {
            IListResponse<User> response = new ListResponse<User>();
            try
            {
                string func = "select * from [dbo].[User]";
                var result = await _dapper.GetAllAsync<User>(func, null, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<IListResponse<RefreshToken>> GetAllRefreshTokensByUserid(int id)
        {
            IListResponse<RefreshToken> response = new ListResponse<RefreshToken>();
            try
            {
                string func = "select * from [dbo].[RefreshToken] where user_id = @Id";
                var result = await _dapper.GetAllAsync<RefreshToken>(func, new {Id=id}, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
                else
                    response.Model = result;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<IResponse> AddRefreshTokensByUserid(RefreshToken token)
        {
            IResponse response = new ErrorResponse();
            try
            {
                string func = "insert into [dbo].[RefreshToken](User_Id, Token, Expiry_Date) values(@User_Id, @Token, @Expiry_Date)";
                await _dapper.Execute(func, new { User_Id = token.User_Id, Token  = token.Token, Expiry_Date  = token.Expiry_Date}, CommandType.Text);

                if (_dapper._InfoRespuesta.ExisteError)
                    response.Respuesta = _dapper._InfoRespuesta;
               
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
    }
}
