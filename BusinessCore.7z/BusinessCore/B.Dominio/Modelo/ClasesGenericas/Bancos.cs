﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.ClasesGenericas
{
    public enum Bancos:int
    {
        BLNI = 1,
        BLHN = 2,
        BLPA = 3,
        BLCR = 4,
        BLRD = 5,
        REGIONAL = 6
    }
}
