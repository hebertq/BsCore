﻿using BPMLogger.ClasesGenericas;
using System;

namespace BPMLogger
{
    public class LoggerBMP : ILoggerBMP
    {
        /// <summary>
        /// Objeto para menejo de errores
        /// </summary>
        private LoggerManager Log { get; set; }
        private string RadNumber { get; set; }
        /// <summary>
        /// Id del Proceso (Servicio)
        /// </summary>
        public int Proceso { get; set; } = 23;
        /// <summary>
        /// Enviar errores por Correo
        /// </summary>
        public bool SendErrMail { get; set; } = false;
        /// <summary>
        /// Contructor de la clase
        /// </summary>
        public LoggerBMP()
        {
            Log = new LoggerManager();
        }
        /// <summary>
        /// Variable para indicar el tipo de guardado de errores
        /// </summary>
        public TipoLog LogTipo { set; get; } = TipoLog.DataBase;

        /// <summary>
        /// Metodo para guardar información de tipo INFO
        /// </summary>
        /// <param name="pRadNumber"></param>
        /// <param name="pMetodo"></param>
        /// <param name="pObjeto"></param>
        /// <param name="pTipoContentido"></param>
        /// <param name="pLimpiarBytes"></param>
        public void LogInformation(string pRadNumber, string pMetodo, object pObjeto, MessageContent pTipoContentido, bool pLimpiarBytes = false)
        {
            TipoTransaccion nTipoTransaccion = pTipoContentido == MessageContent.Request || pTipoContentido == MessageContent.Body ? TipoTransaccion.Ninguna: TipoTransaccion.Transaccion;
            try
            {
                string strlog = "";
                SetData(pMetodo, pObjeto, pTipoContentido, pLimpiarBytes, nTipoTransaccion, ref strlog);
                Log.LogInfo(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo);
            }
            catch (Exception e)
            {
                try
                {
                    var strlog = String.Format("Ha ocurrido un error al intentar guardar log método {0}. Detalle excepcion: {1} {2} {3}", pMetodo, e.Message, e.InnerException, e.StackTrace);
                    Log.LogError(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo, e);
                }
                catch { }
            }
            return;
        }

        /// <summary>
        /// Metodo para guardar información de tipo WARN
        /// </summary>
        /// <param name="pRadNumber"></param>
        /// <param name="pMetodo"></param>
        /// <param name="Mensaje"></param>
        public void LogAdvertencia(string pRadNumber, string pMetodo, string Mensaje)
        {
            TipoTransaccion nTipoTransaccion = TipoTransaccion.Ninguna;
            try
            {
                var strlog = pMetodo + " $Info[" + Mensaje + "]";
                Log.LogWarning(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo);
            }
            catch (Exception e)
            {
                try
                {
                    var strlog = String.Format("Ha ocurrido un error al intentar guardar log método {0}. Detalle excepcion: {1} {2} {3}", pMetodo, e.Message, e.InnerException, e.StackTrace);
                    Log.LogError(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo, e);
                }
                catch { }
            }
            return;          
        }

        /// <summary>
        /// Metodo para guardar información de tipo Error
        /// </summary>
        /// <param name="pRadNumber"></param>
        /// <param name="pMetodo"></param>
        /// <param name="mensaje"></param>
        /// <param name="pObjeto"></param>
        /// <param name="pEx"></param>
        public void LogError(string pRadNumber, string pMetodo, string mensaje = "",object pObjeto = null, Exception pEx = null)
        {
            TipoTransaccion nTipoTransaccion = pEx == null ? TipoTransaccion.Ninguna : TipoTransaccion.Exception;
            MessageContent pTipoContentido   = MessageContent.Other;
            bool pLimpiarBytes = false;

            try
            {
                string strlog = mensaje + System.Environment.NewLine;
                SetData(pMetodo, pObjeto, pTipoContentido, pLimpiarBytes, nTipoTransaccion, ref strlog);
                Log.LogError(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo, pEx);

                if(SendErrMail)
                    Log.LogError(strlog, pRadNumber, Proceso, nTipoTransaccion, TipoLog.Email, pEx);
            }
            catch (Exception e)
            {
                try
                {
                    var strlog = String.Format("Ha ocurrido un error al intentar guardar log método {0}. Detalle excepcion: {1} {2} {3}", pMetodo, e.Message, e.InnerException, e.StackTrace);
                    Log.LogError(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo, e);
                }
                catch { }
            }
            return;
        }

        /// <summary>
        /// Error de guardado en archivo
        /// </summary>
        /// <param name="pRadNumber"></param>
        /// <param name="pMetodo"></param>
        /// <param name="mensaje"></param>
        /// <param name="pObjeto"></param>
        /// <param name="pEx"></param>
        public void ErrorFatal(string pRadNumber, string pMetodo, string mensaje = "",object pObjeto = null, Exception pEx = null)
        {
            string strlog = mensaje;
            try
            {
                SetData(pMetodo, pObjeto, MessageContent.Other, false,TipoTransaccion.Ninguna, ref strlog);
                pEx = pEx ?? new Exception("Error Fatal");
                Log.LogFatal(strlog, pRadNumber, Proceso,TipoTransaccion.Ninguna, pEx,TipoLog.File);
            }
            catch (Exception e)
            {
                try
                {
                    strlog = String.Format("Ha ocurrido un error al intentar guardar log método {0}. Detalle excepcion: {1} {2} {3}", pMetodo, e.Message, e.InnerException, e.StackTrace);
                    Log.LogError(strlog, RadNumber, Proceso, TipoTransaccion.Ninguna,LogTipo,e);
                }
                catch { }
            }
        }

        /// <summary>
        /// Log mensaje informativo
        /// </summary>
        /// <param name="pRadNumber"></param>
        /// <param name="pMetodo"></param>
        /// <param name="Mensaje"></param>
        /// <param name="nTipoTransaccion"></param>
		public void MensajeInfo(string pRadNumber, string pMetodo, string Mensaje, TipoTransaccion nTipoTransaccion = TipoTransaccion.Ninguna)
        {
            try
            {
                RadNumber = pRadNumber;
                var strlog = pMetodo + "$Info[" + Mensaje + "]";
                Log.LogInfo(strlog, pRadNumber, Proceso, nTipoTransaccion, LogTipo);
            }
            catch (Exception e)
            {
                try
                {
                    var strlog = String.Format("Ha ocurrido un error al intentar guardar log método {0}. Detalle excepcion: {1} {2} {3}", pMetodo, e.Message, e.InnerException, e.StackTrace);
                    Log.LogError(strlog, RadNumber, Proceso, nTipoTransaccion,LogTipo,e);
                }
                catch { }
            }
            return;
        }

        /// <summary>
        /// función para setear la data enviada desde las interfaces
        /// </summary>
        /// <param name="pMetodo"></param>
        /// <param name="pObjeto"></param>
        /// <param name="pTipoContentido"></param>
        /// <param name="pLimpiarBytes"></param>
        /// <param name="nTipoTransaccion"></param>
        /// <param name="strlog"></param>
        private void SetData(string pMetodo, object pObjeto, MessageContent pTipoContentido, bool pLimpiarBytes, TipoTransaccion nTipoTransaccion, ref string strlog)
        {
            string prefijo = "";
            if (pObjeto == null)
                return;

            if (pLimpiarBytes)
            {
                object copia = pObjeto.AutoCloneObject(true);
                strlog = copia.ToXml();
            }
            else
            // Convertir objeto origen a xml
            { strlog = pObjeto.ToXml(); }

            if (string.IsNullOrEmpty(strlog))
                return;

            switch (pTipoContentido)
            {
                case MessageContent.Request:
                    prefijo = " $Request[";
                    break;
                case MessageContent.Body:
                    prefijo = " $Body[";
                    break;
                case MessageContent.Response:
                    prefijo = " $Response[";
                    break;
                default:
                    prefijo = " $Info[";
                    break;
            }
            strlog = pMetodo + prefijo + System.Environment.NewLine + strlog + "]";
        }
    }
}
