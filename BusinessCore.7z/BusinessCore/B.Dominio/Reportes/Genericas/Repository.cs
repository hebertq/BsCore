﻿using DocumentFormat.OpenXml.Packaging;
using iText.Kernel.Pdf;
using SharpDocx;
using Docentric.Documents.ObjectModel;

namespace Reportes.Genericas
{
    public abstract class Repository
    {
        private readonly string BasePath = System.IO.Path.GetDirectoryName(typeof(Repository).Assembly.Location) + @"/";

        private readonly string viewPath;
        private readonly string documentPath;

        public Repository()
        {
            viewPath     = $"{BasePath}Views/";
            documentPath = $"{BasePath}Documents/";
        }

        public string CrearReporte<T>(T model, string nombredoc, string nombrevie)
        {
            string documentViewer = null;
            //Ide.Start($"{viewPath}{nombrevie}", $"{documentPath}{nombredoc}", model, null, null, documentViewer);
            var document = DocumentFactory.Create($"{viewPath}{nombrevie}", model);
            byte[] bytes;
    
            using (var outputStream = document.Generate())
            {
                // Create new document.
                bytes = ConvertWordToPdfDoc(outputStream);
            }

            return Convert.ToBase64String(bytes);
        }

        public byte[] ConvertWordToPdf(Stream wordStream)
        {
            byte[] buffer;
            using (WordprocessingDocument wordDocument = WordprocessingDocument.Open(wordStream, false))
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    using (var pdfWriter = new PdfWriter(ms))
                    {
                        using (var pdfDocument = new PdfDocument(pdfWriter))
                        {
                            using (var document = new iText.Layout.Document(pdfDocument))
                            {
                                foreach (var paragraph in wordDocument.MainDocumentPart.Document.Body.Elements<DocumentFormat.OpenXml.Wordprocessing.Paragraph>())
                                {
                                    string text = paragraph.InnerText;
                                    document.Add(new iText.Layout.Element.Paragraph(text));
                                }
                            }
                        }
                    }
                    buffer = ms.ToArray();
                }                
            }
            return buffer;
        }

        public byte[] ConvertWordToPdfDoc(Stream wordStream)
        {
            byte[] buffer = null;
            Document doc = Document.Load(wordStream, LoadOptions.Word);
            //using (var reportDocumentStream = new MemoryStream())
            //{
            //    doc.Save(reportDocumentStream, SaveOptions.Pdf);
            //    buffer = reportDocumentStream.ToArray();
            //}           
            return buffer;
        }
    }
}
