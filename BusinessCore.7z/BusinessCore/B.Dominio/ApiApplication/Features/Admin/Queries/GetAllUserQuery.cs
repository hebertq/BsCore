﻿using MediatR;
using Modelo.Admin;
using Modelo.Interfaces;

namespace ApiApplication.Features.Admin.Queries
{
    public record GetAllUserQuery() : IRequest<IListResponse<User>>;
}
