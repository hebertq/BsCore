﻿using System.Xml.Serialization;

namespace Modelo.Entidades
{
    public abstract class CasoBizagi
    {
        public int IdCase { get; set; } = 0;
        public string RadNumber { get; set; } = "RadNumber";
    }

    public class CasoBizagiAct
    {
        public string RadNumber { get; set; } = "";
        public int IdCaseParent { get; set; } = 0;
    }

    public class CasoBizaGestion
    {
        public int IdCtrl { get; set; } = 0;
        public int NoGesSisco { get; set; } = 0;
    }

    public class CasosValidos : CasoBizagi
    {
        public int IdCaseParent { get; set; } = 0;
    }
}