﻿using Modelo.ClasesGenericas;
using Modelo.Entradas;
using Modelo.Interfaces;
using Repositorio.ClasesGenericas;
using Repositorio.Interfaces;
using System.Data;
using System.Reflection;
using System.Threading.Tasks;
using System;
using Utilidades.Interfaces;
using System.Linq;
using System.Collections.Generic;
using Modelo.Entradas.BLNI;

namespace Repositorio.Clases
{
    public class HostNICRepositorio: ServiceHost, IHostIBSNicaragua
    {
        public HostNICRepositorio(IUtilidades _Util) : base(_Util) { }
        public async Task<ISingleResponse<responseDataString>> ObtenerRiesgoxActividad(string actividadEconomica)
        {
            ISingleResponse<responseDataString> response = new SingleResponse<responseDataString>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto   = InfoContextDB2.AS400NI,
                    Orden      = 1,
                    Nombre_SP  = "SPBIZ0185OBTIENERIESGOXACTIVIDAD",
                    Parametros = new { ICHRACTIVIDADECONOMICA = actividadEconomica }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string,string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {
                    var reg = registro.Data.Model.Where(x=> x.Key.Equals("OCHRRIESGO")).FirstOrDefault();
                    if (reg.Value != null)
                        response.Model.Data = reg.Value;
                    else
                        response.Model = new responseDataString();

                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxRiesgo(string riesgoAutomatico)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto   = InfoContextDB2.AS400NI,
                    Orden      = 1,
                    Nombre_SP  = "SPBIZ0186OBTIENECALIFICACIONXRIESGO",
                    Parametros = new { OCHRRIESGO = riesgoAutomatico }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                  
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if(error != 0)
                    {                       
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = int.Parse(reg.Value);
                        else
                            response.Model = 0;
                    }                   
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<ISingleResponse<int>> ObtenerCalificacionxRiesgoManual(decimal ciente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0279GETCALIFICACIONRIESGOCLIENTEMAN",
                    Parametros = new { INUMCAMCUS = ciente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = int.Parse(reg.Value);
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }

        public async Task<ISingleResponse<int>> ObtenerCalificacionPnpPepAltoRiesgoRelacionado(decimal NoCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto   = InfoContextDB2.AS400NI,
                    Orden      = 1,
                    Nombre_SP  = "SPBIZ0218PNPOALTORIESGOPEPRELACIONADO",
                    Parametros = new { IDECCUSCUN = NoCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataSet");
                var registro = await PostAsync<SingleResponse<DataSet>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {
                    var reg = registro.Data.Model.Tables[0].Rows.Count;
                    if (reg > 0)
                        response.Model = 3;
                    else
                        response.Model = 0;
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxPais(string sPais)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0188OBTIENECALIFICACIONXPAIS",
                    Parametros = new { ICHRPAISPROCEDENCIA = sPais }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                  
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxDepartamento(string sDep)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto   = InfoContextDB2.AS400NI,
                    Orden      = 1,
                    Nombre_SP  = "SPBIZ0189OBTIENECALIFICACIONXDEPTO",
                    Parametros = new { ICHRDEPARTAMENTO = sDep }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                  
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxActividadSinRiesgoAsociado(string sActividad)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0191OBTIENECALIFICACIONXACTIVIDADSINRIESGO",
                    Parametros = new { ICHRACTIVIDADECONOMICA = sActividad }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                   
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxProductoCtas(List<CuentaRiesgo> LCuentaRiesgos)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            List<int> lCalificaciones = null;
            int iResultado = 0;
            string sCalificacion = string.Empty;
            string sCreaTipClasificacion = string.Empty;
            try
            {
                lCalificaciones = new List<int>();
                foreach (var oItem in LCuentaRiesgos)
                {

                    sCreaTipClasificacion = string.Concat(oItem.TipoCuenta, oItem.Clasificacion.PadLeft(2, '0'));
                    if (sCreaTipClasificacion.ToUpper().Equals("SAV01") && oItem.Gl.Equals("210201001001")) //GL CTA AHORRO
                        lCalificaciones.Add(2);
                    else
                    {
                        var exec = new ExecuteSP<object>
                        {
                            Contexto = InfoContextDB2.AS400NI,
                            Orden = 1,
                            Nombre_SP = "SPBIZ0194OBTIENECALIFICACIONXPRODUCTO",
                            Parametros = new { ICHRTIPOCTACLASIFICACION = sCreaTipClasificacion, ICHRGL = oItem.Gl }
                        };

                        var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                        var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                        if (registro.IsSuccess)
                        {
                            var reg = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault().Value;
                            if (int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value) != 0)
                            {
                                throw new Exception(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value);
                            }
                            else
                            {
                                sCalificacion = registro.Data.Model.Where(x => x.Key.Equals("OCHRCALIFICACION")).FirstOrDefault().Value;
                                lCalificaciones.Add(Convert.ToInt16(sCalificacion));

                                if (sCalificacion == "0")
                                {
                                    throw new Exception("Calificación no válida para clasificación (" + sCreaTipClasificacion + ")  de la cuenta. ");
                                }
                            }                           
                        }
                        else
                            response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());                       
                    }
                }

                iResultado = lCalificaciones.Count > 0 ? lCalificaciones.Max() : 0;
                response.Model = iResultado;
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionBACKTOBACK(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto   = InfoContextDB2.AS400NI,
                    Orden      = 1,
                    Nombre_SP  = "SPBIZ0259GETBACKTOBACK",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro   = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                   
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                        {
                            int cantBackToBack = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                            response.Model = cantBackToBack > 0 ? (int)TiposCalificacion.RiesgoAlto : 0;
                        }
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }      
        public async Task<ISingleResponse<int>> ObtenerCalificacionTCPREPAGO(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0260TCPREPAGO",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                   
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                        {
                            int cantTcPrepagos = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                            response.Model = cantTcPrepagos > 0 ? (int)TiposCalificacion.RiesgoAlto : 0;
                        }
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionTCDEBITO(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0261TCDEBITO",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                    
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                        {
                            int calificacion = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                            response.Model = calificacion > 0 ? (int)TiposCalificacion.RiesgoBajo : 0;
                        }
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionCrcFideicomisos(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0262CRCAUTOMATICOFIDEICOMISOS",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                 
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionFIDEICOMISOS(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0263CALIFICACIONFIDEICOMISOS",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                 
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<IListResponse<PrestamosAsociados>> ObtenerCalificacionPRESTAMOS(decimal noCliente)
        {
            IListResponse<PrestamosAsociados> response = new ListResponse<PrestamosAsociados>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0264PRESTAMOS",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataSet");
                var registro = await PostAsync<SingleResponse<DataSet>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {
                    response.Model = _Util.ConvertTo<PrestamosAsociados>(registro.Data.Model.Tables[0]);
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionCERTIFICADODTO(decimal noCliente)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0266CERTIFICADODTO",
                    Parametros = new { IDECCUSCUN = noCliente }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                  
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                        {
                            int calificacion = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                            response.Model = calificacion > 0 ? (int)TiposCalificacion.RiesgoBajo : 0;
                        }                          
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<decimal>> ObtenerTasaCambio(decimal noCliente, string sTipo)
        {
            ISingleResponse<decimal> response = new SingleResponse<decimal>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0005GETTASACAMBIO",
                    Parametros = new { IINTNOCLIENTE = noCliente, IINTTIPO = sTipo }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataSet");
                var registro = await PostAsync<SingleResponse<DataSet>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {
                    var result = registro.Data.Model.Tables[0]
                                                     .AsEnumerable()
                                                     .Where(myRow => myRow.Field<string>("MONEDA") == "USD" && myRow.Field<string>("TIPO") == "0")
                                                     .Select(myRow => myRow.Field<double>("TASAVENTA"))
                                                     .FirstOrDefault();
                   
                    response.Model = result == 0 ? 1 :decimal.Parse(result.ToString());
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());

            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }

            return response;
        }
        public async Task<ISingleResponse<int>> ObtenerCalificacionxRiesgoPLD(string Riesgo, string Tipo)
        {
            ISingleResponse<int> response = new SingleResponse<int>();
            try
            {
                var exec = new ExecuteSP<object>
                {
                    Contexto = InfoContextDB2.AS400NI,
                    Orden = 1,
                    Nombre_SP = "SPBIZ0215OBTIENECALIFICACIONXRIESGOPLD",
                    Parametros = new { OCHRRIESGO = Riesgo, OCHRTIPO = Tipo }
                };

                var requestUrl = CreateRequestUri("Repositorio/GetDataParamOut");
                var registro = await PostAsync<SingleResponse<Dictionary<string, string>>, ExecuteSP<object>>(requestUrl, exec);
                if (registro.IsSuccess)
                {                  
                    var error = int.Parse(registro.Data.Model.Where(x => x.Key.Equals("OINTCODERROR")).FirstOrDefault().Value);
                    if (error != 0)
                    {
                        response.Respuesta.SetErrorApi(registro.Data.Model.Where(x => x.Key.Equals("OVARMENSAJEERROR")).FirstOrDefault().Value, "ObtenerCalificacionxRiesgo");
                    }
                    else
                    {
                        var reg = registro.Data.Model.Where(x => x.Key.Equals("OINTCALIFICACION")).FirstOrDefault();
                        if (reg.Value != null && reg.Value != " ")
                            response.Model = Convert.ToInt32(reg.Value.Trim().Equals(string.Empty) ? "0" : reg.Value.Trim());
                        else
                            response.Model = 0;
                    }
                }
                else
                    response.Respuesta.SetErrorApi(registro.ReturnMessage, MethodBase.GetCurrentMethod().ToString());
            }
            catch (Exception ex)
            {
                response.Respuesta.SetErrorExep(ErrorType.Datos, ex, MethodBase.GetCurrentMethod().ToString());
            }
            return response;
        }
    }  
}

