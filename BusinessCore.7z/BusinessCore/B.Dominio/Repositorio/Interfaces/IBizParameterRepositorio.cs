﻿using Modelo.Entradas.BLNI;
using Modelo.Interfaces;
using System.Threading.Tasks;

namespace Repositorio.Interfaces
{
    public interface IBizParameterRepositorio
    {
        Task<IResponse> AddCalificacionRiesgo(typecalificacion request);
    }
}
