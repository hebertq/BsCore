﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Modelo.ClasesGenericas;

namespace ApiApplication.Extensions
{
    public class ValuesCheckRouteParameterHandler : AuthorizationHandler<ValuesRouteRequirement>
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ValuesCheckRouteParameterHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ValuesRouteRequirement requirement)
        {
            var routeValues = _httpContextAccessor.HttpContext.Request.RouteValues;
            object bank;
            routeValues.TryGetValue("bank", out bank);

            foreach (string item in Enum.GetNames(typeof(Bancos)))
            {
                if (bank.ToString() == item)
                {
                    context.Succeed(requirement);
                }
            }          
            return Task.CompletedTask;
        }
    }
}
