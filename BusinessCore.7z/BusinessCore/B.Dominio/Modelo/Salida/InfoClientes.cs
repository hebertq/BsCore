﻿using Modelo.Entidades;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Modelo.Salida
{
    /// <summary>
    /// Consulta de Clientes
    /// </summary>
    public class InfoClientes
    {
        public List<Cliente> Clientes;
        public int TotalCoincidencias = 0;
        public List<File> ResultadoBusqueda = new List<File>();
    }

    public class File
    {
        [XmlAttribute("fileName")]
        public string fileName = "fileName=";
        public byte[] data;
    }
}
