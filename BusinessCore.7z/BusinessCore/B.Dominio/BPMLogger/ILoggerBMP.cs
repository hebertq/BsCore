﻿using BPMLogger.ClasesGenericas;
using System;

namespace BPMLogger
{
    public interface ILoggerBMP
    {
        void LogInformation(string pRadNumber, string pMetodo, object pObjeto, MessageContent pTipoContentido, bool pLimpiarBytes = false);
        void LogAdvertencia(string pRadNumber, string pMetodo, string Mensaje);
        void LogError(string pRadNumber, string pMetodo, string mensaje = "", object pObjeto = null, Exception pEx = null);
        void ErrorFatal(string pRadNumber, string pMetodo, string mensaje = "",object pObjeto = null, Exception pEx = null);      
        TipoLog LogTipo { set; get;}
        int Proceso { get; set; }
        bool SendErrMail { get; set; } 
    }
}
