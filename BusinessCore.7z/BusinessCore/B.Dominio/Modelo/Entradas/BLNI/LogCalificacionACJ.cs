﻿using Modelo.ClasesGenericas;
using System.Xml.Serialization;

namespace Modelo.Entradas.BLNI
{
    public class LogCalificacionACJ
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        [XmlAttribute(AttributeName = "Puntaje")]
        public int Puntaje { set; get; } = 0;       
        public LogCalificacionActividadEconomica Actividad_Economica { set; get; } = new LogCalificacionActividadEconomica();
        public LogCalificacionPais Riesgo_geografico { set; get; } = new LogCalificacionPais();
        public LogCalificacionProducto Poducto { set; get; } = new LogCalificacionProducto();
        public LogCalificacionCredito Creditos { set; get; } = new LogCalificacionCredito();        
    }

    public class LogCalificacionDifACJ
    {
        [XmlAttribute(AttributeName = "Calificacion")]
        public int CalificacionFinal { set; get; } = 0;
        public string NoCaso { set; get; } = string.Empty;
        public string NoCliente { set; get; } = string.Empty;
        public int RiesgosPreDefinido { set; get; } = 0;
        public int Fideicomisos { set; get; } = 0;
        public LogCalificacionActividadEconomica Actividad_Economica { set; get; } = new LogCalificacionActividadEconomica();
        public LogCalificacionPep Pep { set; get; } = new LogCalificacionPep();
        public LogCalificacionACJ CalificacionLA { set; get; } = new LogCalificacionACJ();
        public LogCalificacionACJ CalificacionFT { set; get; } = new LogCalificacionACJ();
        public LogCalificacionACJ CalificacionFP { set; get; } = new LogCalificacionACJ();
    }
}
