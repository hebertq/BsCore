﻿
using Modelo.ClasesGenericas;

namespace Modelo.Entradas.BLNI
{
    public class typecalificacion
    {
        public string NoCaso { set; get; } = string.Empty;
        public int IdCase { set; get; } = 0;
        public decimal NoCliente { set; get; } = 0;
        public bool RiesgoDir { set; get; } = false;
        public int CRC { set; get; } = 0;
        public int RiesgoAuto { set; get; } = 0;
        public int ActEcoLA { set; get; } = 0;
        public int RiesgoGeoLA { set; get; } = 0;
        public int ProducAsocLA { set; get; } = 0;
        public int SumCredLA { set; get; } = 0;
        public int CantCredLA { set; get; } = 0;
        public int PuntajeLA { set; get; } = 0;
        public int CRCLA { set; get; } = 0;
        public int ActEcoFT { set; get; } = 0;
        public int RiesgoGeoFT { set; get; } = 0;
        public int ProducAsocFT { set; get; } = 0;
        public int SumCredFT { set; get; } = 0;
        public int CantCredFT { set; get; } = 0;
        public int PuntajeFT { set; get; } = 0;
        public int CRCFT { set; get; } = 0;
        public int ActEcoFP { set; get; } = 0;
        public int RiesgoGeoFP { set; get; } = 0;
        public int ProducAsocFP { set; get; } = 0;
        public int SumCredFP { set; get; } = 0;
        public int CantCredFP { set; get; } = 0;
        public int PuntajeFP { set; get; } = 0;
        public int CRCFP { set; get; } = 0;
        public string Motivo   {set;get;} = string.Empty;
        public string Usuario  {set;get;} = string.Empty;

        public void setMotivoCal(MotivosCalCRC motivo, int cal,bool riesgo = false,int riesgoauto = 0)
        {
            Motivo     = motivo.ToString();
            CRC        = cal;
            RiesgoDir  = riesgo;
            RiesgoAuto = riesgoauto;

            if (riesgoauto > 0)
                setDataAuto();
        }

        public void setDataDif(LogCalificacionDifNat data)
        {
            if(data.CalificacionLA.CalificacionFinal > 0 && data.CalificacionFP.CalificacionFinal > 0 && data.CalificacionFT.CalificacionFinal > 0 && RiesgoAuto == 0)
            {
               //****************** Calificacion LA *********************
                ActEcoLA     = data.CalificacionLA.Actividad_Economica.Calificacion;
                RiesgoGeoLA  = data.CalificacionLA.Riesgo_geografico.Calificacion;
                ProducAsocLA = data.CalificacionLA.Poducto.Calificacion;
                SumCredLA    = data.CalificacionLA.Creditos.sumCreditos;
                CantCredLA   = data.CalificacionLA.Creditos.cantCreditos;
                PuntajeLA    = data.CalificacionLA.Puntaje;
                CRCLA        = data.CalificacionLA.CalificacionFinal;
                //****************** Calificacion FT *********************
                ActEcoFT     = data.CalificacionFT.Actividad_Economica.Calificacion;
                RiesgoGeoFT  = data.CalificacionFT.Riesgo_geografico.Calificacion;
                ProducAsocFT = data.CalificacionFT.Poducto.Calificacion;
                SumCredFT    = data.CalificacionFT.Creditos.sumCreditos;
                CantCredFT   = data.CalificacionFT.Creditos.cantCreditos;
                PuntajeFT    = data.CalificacionFT.Puntaje;
                CRCFT        = data.CalificacionFT.CalificacionFinal;
                //****************** Calificacion FP *********************
                ActEcoFP     = data.CalificacionFP.Actividad_Economica.Calificacion;
                RiesgoGeoFP  = data.CalificacionFP.Riesgo_geografico.Calificacion;
                ProducAsocFP = data.CalificacionFP.Poducto.Calificacion;
                SumCredFP    = data.CalificacionFP.Creditos.sumCreditos;
                CantCredFP   = data.CalificacionFP.Creditos.cantCreditos;
                PuntajeFP    = data.CalificacionFP.Puntaje;
                CRCFP        = data.CalificacionFP.CalificacionFinal;
            }
        }

        public void setDataAuto()
        {           
             //****************** Calificacion LA *********************
             ActEcoLA     = 0;
             RiesgoGeoLA  = 0;
             ProducAsocLA = 0;
             SumCredLA    = 0;
             CantCredLA   = 0;
             PuntajeLA    = 0;
             CRCLA        = CRC;
             //****************** Calificacion FT *********************
             ActEcoFT     = 0;
             RiesgoGeoFT  = 0;
             ProducAsocFT = 0;
             SumCredFT    = 0;
             CantCredFT   = 0;
             PuntajeFT    = 0;
             CRCFT        = CRC;
             //****************** Calificacion FP *********************
             ActEcoFP     = 0;
             RiesgoGeoFP  = 0;
             ProducAsocFP = 0;
             SumCredFP    = 0;
             CantCredFP   = 0;
             PuntajeFP    = 0;
             CRCFP        = CRC;
        }
        public void setDataDif(LogCalificacionDifACJ data)
        {
            if (data.CalificacionLA.CalificacionFinal > 0 && data.CalificacionFP.CalificacionFinal > 0 && data.CalificacionFT.CalificacionFinal > 0)
            {
                //****************** Calificacion LA *********************
                ActEcoLA = data.CalificacionLA.Actividad_Economica.Calificacion;
                RiesgoGeoLA = data.CalificacionLA.Riesgo_geografico.Calificacion;
                ProducAsocLA = data.CalificacionLA.Poducto.Calificacion;
                SumCredLA = data.CalificacionLA.Creditos.sumCreditos;
                CantCredLA = data.CalificacionLA.Creditos.cantCreditos;
                PuntajeLA = data.CalificacionLA.Puntaje;
                CRCLA = data.CalificacionLA.CalificacionFinal;
                //****************** Calificacion FT *********************
                ActEcoFT = data.CalificacionFT.Actividad_Economica.Calificacion;
                RiesgoGeoFT = data.CalificacionFT.Riesgo_geografico.Calificacion;
                ProducAsocFT = data.CalificacionFT.Poducto.Calificacion;
                SumCredFT = data.CalificacionFT.Creditos.sumCreditos;
                CantCredFT = data.CalificacionFT.Creditos.cantCreditos;
                PuntajeFT = data.CalificacionFT.Puntaje;
                CRCFT = data.CalificacionFT.CalificacionFinal;
                //****************** Calificacion FP *********************
                ActEcoFP = data.CalificacionFP.Actividad_Economica.Calificacion;
                RiesgoGeoFP = data.CalificacionFP.Riesgo_geografico.Calificacion;
                ProducAsocFP = data.CalificacionFP.Poducto.Calificacion;
                SumCredFP = data.CalificacionFP.Creditos.sumCreditos;
                CantCredFP = data.CalificacionFP.Creditos.cantCreditos;
                PuntajeFP = data.CalificacionFP.Puntaje;
                CRCFP = data.CalificacionFP.CalificacionFinal;
            }
        }
    }   
}
