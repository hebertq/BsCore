﻿namespace BPMLogger.ClasesGenericas
{
	public enum TipoTransaccion
	{
		Ninguna     = 0,
		Transaccion = 1,
		Consulta    = 2,
		Exception   = 3
	}
	public enum MessageContent
	{
		Other    = 0,
		Request  = 1,
		Body     = 2,
		Response = 3
	}
	public enum TipoLog
	{
		DataBase   = 1,
		File       = 2,
		Email      = 3
	}
}
